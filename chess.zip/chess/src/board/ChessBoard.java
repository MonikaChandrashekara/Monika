package board;

//import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

//import pieces.ChessPiece;
//import pieces.EmptySpace;

public class ChessBoard
{

	// HashMap to store the position occupied by chess pieces 
	static HashMap<String, Integer> positionMap = new HashMap<>();
	
	// 2d array to store the chess board
	private int[][] board;

	// function to initialize the chess board 
	public ChessBoard()
	{
		this.board = new int[8][8];
		for (int i = 0; i < 8; i++) 
		{
			for (int j = 0; j < 8; j++)
			{

				this.board[i][j] = 0;
			}
		}
	}

	
	// function to calculate the possible moves of pawn 
	public static void movePawn(ChessBoard obj, int i, int j, ArrayList<String> alphabets,ArrayList<Integer> numbers)
	{

		int count = 0;
		
		// Hashmap to store the possible positions for pawn
		HashMap<Integer, String> hm = new HashMap<Integer, String>();

		// if the row is 7 the pawn can not move further 	
		if(i!=7)
		{
		
			// if the position in the  row ahead  is empty the pawn can move there 
			 if( obj.board[i+1][j]!=1 )
			{
				System.out.println("The possible positon for the pawn to move is : " + " " + count + ": " + numbers.get(i+1)
				+ alphabets.get(j));
		        hm.put(count, String.valueOf(numbers.get(i + 1)) + alphabets.get(j));
		        count++;
			}
			 
			 // if the diagonal position to the right of the pawn is free 
	
		if(  j+1<=7 && obj.board[i+1][j+1]!=1) 
		{
			
			System.out.println("The possible positon for the pawn to move is : " + " " + count + ": " + numbers.get(i+1)
			+ alphabets.get(j+1));
	        hm.put(count, String.valueOf(numbers.get(i+1)) + alphabets.get(j+1));
	       count++;
		}
		
		// if the diagonal position to the left of the pawn is free 
		if( j-1 >=0 && obj.board[i+1][j-1]!=1  )
		{
			System.out.println("left");
			System.out.println("The possible positon for the pawn to move is : " + " " + count + ": " + numbers.get(i+1)
			+ alphabets.get(j-1));
	        hm.put(count, String.valueOf(numbers.get(i+1)) + alphabets.get(j-1));
	       count++;
		}
		
		
		System.out.println("Select the position number " + hm.keySet() + " you want the pawn to move to : ");

		Scanner sc = new Scanner(System.in);
		int z = sc.nextInt();
		
		System.out.println("You have choosen to move the pawn to this position :" + hm.get(z));
		
		// taking the input from the user for the required position to move the pawn
		String[] x = hm.get(z).split("");
		int b = Integer.parseInt(x[0]);
		String d = x[1];
		
		// making the new position of the pawn as 1
		obj.board[b - 1][alphabets.indexOf(String.valueOf(d))] = 1;
		positionMap.put(String.valueOf(b) + String.valueOf(d), 1);
		showBoard(obj);	
		
	}
		else
			System.out.println(" There is no path as the end of the board is reached");
		
	}

	
	// function to calculate the possible moves of Queen 
	public static void moveQueen(ChessBoard obj, int i, int j, ArrayList<String> alphabets,ArrayList<Integer> numbers) 
	
	{
		
		int count = 0;
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		// to calculate if the rows ahead are free in the forward direction 
		for( int x=1 ; x+i<8 ;x++)
		{
			
			if(obj.board[x+i][j]==1) // increment row value & keep column value constant 
			{
				break;
			}
			
			else
			{
				System.out.println("The possible positons to move queen vertically : "  + count + ": " + numbers.get(i+x)
				+ alphabets.get(j));
		       hm.put(count, String.valueOf(numbers.get(i + x)) + alphabets.get(j));
		        count++;
			}
			
		}
		
		// to calculate if the rows behind are free in backward direction 
		for(int x=1 ; i-x>=0 ; x++)
		{
			if(obj.board[i-x][j]==1)  // decrement row value & keep column value constant
			{
				break;
			}
			else
			{
				System.out.println("The possible positons to queen move vertically : "  + count + ": " + numbers.get(i-x)
				+ alphabets.get(j));
		       hm.put(count, String.valueOf(numbers.get(i - x)) + alphabets.get(j));
		        count++;
			}
			
		}
		
		// to calculate if the columns are free toward the right direction 
		for( int x=1;j+x<8 ;x++)
		{
			
			if(obj.board[i][j+x]==1) // increment column value  & keep row value constant 
			{
				break;
			}
			else
			{
				System.out.println("The possible positons to move queen horizontally : "   + count + ": " + numbers.get(i)
				+ alphabets.get(j+x));
		       hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j+x));
		        count++;
			}
		}
		
		// to calculate if the columns are free toward the left direction 
		for(int x=1 ; j-x>=0 ; x++)
		{
			if(obj.board[i][j-x]==1)     // decrement  column value  & keep row value constant 
			{
				break;
			}
			
			else
			{
				System.out.println("The possible positons to move queen horizontally : "  + count + ": " + numbers.get(i)
				+ alphabets.get(j-x));
		       hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j-x));
		        count++;
			}
		}
		
		
	// to calculate diagonal movement of queen 	
		
		int temp1=i;
		int temp2=j;
		
		// to calculate the lower left diagonal 
		while(i<=7 && j<=7)
		{
		
				if (obj.board[i++][j++]!=1 && j<=7 && i<=7) // increment both row and column value 
				{
					System.out.println("Possible positions to move the queen diagonally :" + count + ": "
							+ numbers.get(i) + alphabets.get(j));
					hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
					count++;
					
				}
		}
		
		
		i= temp1;
		j= temp2;
		
		// to calculate the upper left diagonal 
		while(i>=0 && j>=0)
		{
			if(obj.board[i--][j--]!=1 && j>=0 && i>=0) // decrement  both row and column value
			{
				System.out.println("Possible positions to move the queen diagonally :" + count + ": "
						+ numbers.get(i) + alphabets.get(j));
				hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
				count++;
			}
		}
				
		
		i=temp1;
		j=temp2;
		
		// to calculate the upper right diagonal 
		while(i>=0 && j<=7)
		{
			if( obj.board[i--][j++]!=1 && j<=7 && i>=0) // decrement row & increment column value 
			{
				System.out.println("Possible positions to move the queen diagonally :" + count + ": "
						+ numbers.get(i) + alphabets.get(j));
				hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
				count++;
			}
		}
				
		
		i=temp1;
		j=temp2;
		
		// to calculate the lower right diagonal 
		while(i<=7 && j>=0)
		{
			if(obj.board[i++][j--]!=1 && j>=0 && i<=7) // increment row & decrement column value 
			{
				System.out.println("Possible position to move the queen diagonally :" + count + ": "
						+ numbers.get(i) + alphabets.get(j));
				hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
				count++;
			}
		}
			

        System.out.println("Select the position number " + hm.keySet() + " you want the Queen to  : ");

		Scanner sc = new Scanner(System.in);

		int z = sc.nextInt();
		System.out.println("You have choosen to move the queen to this position :" + hm.get(z));
		
		String[] x = hm.get(z).split("");
		int b = Integer.parseInt(x[0]);
		String d = x[1];
		
		// making the new position of the queen as 1
		obj.board[b - 1][alphabets.indexOf(String.valueOf(d))] = 1;
		positionMap.put(String.valueOf(b) + String.valueOf(d), 1);
		showBoard(obj);
	}

	
	
	// Function to calculate the possible position for King to move in forward direction 
	
	public static void moveKingFoward(ChessBoard obj, int i, int j, ArrayList<String> alphabets, ArrayList<Integer> numbers) 
	{

		int count = 0;
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		int a1 = i;
		int a2 = j;
		
		// if the row is 7 the king can't move any further [ array dimension ]
		if (i < 7)
		{
             // row value is incremented  and column value remains the same 
			if (obj.board[i + 1][j] == 1)
			{
				System.out.println("There is already a chess piece occupying the position in front");
			}

			else
			{
				System.out.println("The possible positon for the king to move forward : " + " " + count + ": "
						+ numbers.get(i+1) + alphabets.get(j));
				hm.put(count, String.valueOf(numbers.get(i + 1)) + alphabets.get(j));
				count++;
			}
			
		} 
		else
		{
			System.out.println("There are no more paths  to move forward as the end of board is reached");
		}

		moveKingBackward(obj, a1, a2, alphabets, hm,numbers);
	}

	
//	Function to calculate the possible position for King to move in backward direction 
	
	public static void moveKingBackward(ChessBoard obj, int i, int j, ArrayList<String> alphabets,
			HashMap<Integer, String> hm,ArrayList<Integer> numbers) 
	
	{

		int count = hm.keySet().size();

		int b1 = i;
		int b2 = j;
		
// if the row value is 0 the king can not move back [ array dimension ]
		if (i!=0) 
		{
            // decrement row value and keep column value same 
			if (obj.board[i - 1][j] == 1) 
			{
				System.out.println("There is already a chess piece occupying the position at the back");
			}
			else
			{
				System.out.println("The possible positon for the king to move backward is : " + " " + count + ": "
						+numbers.get(i - 1) + alphabets.get(j));
				hm.put(count, String.valueOf(numbers.get(i - 1)) + alphabets.get(j));
				count++;
			}

		} 
		else 
		{
			System.out.println("There are no more paths  to move backward as the end of board is reached");
		}

		moveKingLeft(obj, b1, b2, alphabets, hm , numbers);
	}

	//Function to calculate the possible position for King to move to the left block 	
	
	public static void moveKingLeft(ChessBoard obj, int i, int j, ArrayList<String> alphabets,
			HashMap<Integer, String> hm , ArrayList<Integer> numbers) {

		int count = hm.keySet().size();


		int c1 = i;
		int c2 = j;

		// if the column value is 0 the king can't move to to the block to its left [ array dimension ]
		if (j != 0)
		{

			if (obj.board[i][j - 1] == 1) //  keep row value constant  and decrement column value 
			{
				System.out.println("There is already a chess piece occupying the position to the left");
			}
			
			else
			{
				System.out.println("The possible positon for the king to move left is : " + " " + count + ": " + numbers.get(i)
				+ alphabets.get(j - 1));
		hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j - 1));
		count++;
			}

		} 
		else 
		{
			System.out.println("There are no  paths to move towards the left of the board ");
		}

		moveKingRight(obj, c1, c2, alphabets, hm , numbers);
	}

	
	//Function to calculate the possible position for King to move to the right block	
	
	public static void moveKingRight(ChessBoard obj, int i, int j, ArrayList<String> alphabets,
			HashMap<Integer, String> hm , ArrayList<Integer> numbers) {

		int count = hm.keySet().size();

		// if the column value is 7 the king can't move to the right 
		if (j != 7)
		{

			if (obj.board[i][j + 1] == 1) // keep row value constant  and increment column value 
			{
				System.out.println("There is already a chess piece occupying the position to the right");
			}
			else
			{
				System.out.println("The possible positon for the king to move right is : " + " " + count + ": " + numbers.get(i)
				+ alphabets.get(j+1));
		hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j+1));
		count++;
			}

		} 
		else
		{
			System.out.println("There are no  paths to move towards the right of the board ");
		}

		System.out.println("Select the position number " + hm.keySet() + " you want the King to move to : ");

		Scanner sc = new Scanner(System.in);

		int z = sc.nextInt();
		System.out.println("You have choosen to move the King to this position :" + hm.get(z));
		String[] x = hm.get(z).split("");
		int b = Integer.parseInt(x[0]);
		String d = x[1];
		
		// making the new position of the king as 1
		obj.board[b - 1][alphabets.indexOf(String.valueOf(d))] = 1;
		positionMap.put(String.valueOf(b) + String.valueOf(d), 1);
		showBoard(obj);

	}

	// Function to calculate the possible movements of Knight 
	public static void moveKnight(ChessBoard obj, int i, int j, ArrayList<String> alphabets,ArrayList<Integer> numbers) {

		int count = 0;
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		// In each co-ordinate the row and column value is either increment or decrement by +/- 1 & +/-2
		
		int[] horseMove= { 1 , 2 ,  2 , 1 ,  -1 ,2 ,  -2 , 1 ,  1 , -2 ,  2 ,-1 ,  -1 , -2 ,  -2 , -1};
		
		for(int x=0; x<16 ;x+=2)
		{
			if(i+horseMove[x]>=0 && i+horseMove[x]<8 && j+horseMove[x+1]>=0 && j+horseMove[x+1]<8) // condition to  check if the piece is within the board 
			{
				if(obj.board[i+horseMove[x]][j+horseMove[x+1]]!=1)
				{
					System.out.println("The possible positons for the Knight to move are : " + " " + count + ": " + numbers.get(i+horseMove[x])
					+ alphabets.get(j+horseMove[x+1]));
			hm.put(count, String.valueOf(numbers.get(i+horseMove[x])) + alphabets.get(j+horseMove[x+1]));
			count++;
				}
			}
		}
		
			System.out.println("Select the position number " + hm.keySet() + " you want the kinght to move to : ");

			Scanner sc = new Scanner(System.in);

			int z = sc.nextInt();
			System.out.println("You have choosen to move the knight to this position :" + hm.get(z));
			String[] x = hm.get(z).split("");
			int b = Integer.parseInt(x[0]);
			String d = x[1];
			// making the new position of the king as 1
			obj.board[b - 1][alphabets.indexOf(String.valueOf(d))] = 1;
			positionMap.put(String.valueOf(b) + String.valueOf(d), 1);
			showBoard(obj);
			
		}
	
	
	// function to calculate possible moves for Rook 
	
	public static void moveRook(ChessBoard obj, int i, int j, ArrayList<String> alphabets,ArrayList<Integer> numbers) {

		int count = 0;
		HashMap<Integer, String> hm = new HashMap<Integer, String>();

		
		// to calculate if the rows ahead are free in the forward direction 
		for( int x=1 ; x+i<8 ;x++)
		{
			
			if(obj.board[x+i][j]==1) //increment row value & keep column value constant
			{
				break;
			}
			
			else
			{
				System.out.println("The possible positons for the Rook to move are : " + " " + count + ": " + numbers.get(i+x)
				+ alphabets.get(j));
		       hm.put(count, String.valueOf(numbers.get(i + x)) + alphabets.get(j));
		        count++;
			}
			
		}
		
		//to calculate if the rows behind are free in backward direction 
		for(int x=1 ; i-x>=0 ; x++)
		{
			if(obj.board[i-x][j]==1) // decrement row value & keep column value constant

			{
				break;
			}
			else
			{
				System.out.println("The possible positons for the Rook to move are : " + " " + count + ": " + numbers.get(i-x)
				+ alphabets.get(j));
		       hm.put(count, String.valueOf(numbers.get(i - x)) + alphabets.get(j));
		        count++;
			}
			
		}
		
		// to calculate if the columns are free toward the right direction 

		for( int x=1;j+x<8 ;x++)
		{
			
			if(obj.board[i][j+x]==1)  // increment column value  & keep row value constant

			{
				break;
			}
			else
			{
				System.out.println("The possible positons for the Rook to move are : " + " " + count + ": " + numbers.get(i)
				+ alphabets.get(j+x));
		       hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j+x));
		        count++;
			}
		}
		
		//to calculate if the columns are free toward the left direction 
		
		for(int x=1 ; j-x>=0 ; x++)
		{
			if(obj.board[i][j-x]==1) // decrement  column value  & keep row value constant 

			{
				break;
			}
			
			else
			{
				System.out.println("The possible positons for the Rook to move are : " + " " + count + ": " + numbers.get(i)
				+ alphabets.get(j-x));
		       hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j-x));
		        count++;
			}
		}
		
		
			
	    System.out.println("Select the position number " + hm.keySet() + " you want the Rook to move to : ");

			Scanner sc = new Scanner(System.in);

			int z = sc.nextInt();
			System.out.println("You have choosen to move the Rook to this position :" + hm.get(z));
			String[] x = hm.get(z).split("");
			int b = Integer.parseInt(x[0]);
			String d = x[1];
			
		// making the new position of the Rook as 1
			obj.board[b - 1][alphabets.indexOf(String.valueOf(d))] = 1;
			positionMap.put(String.valueOf(b) + String.valueOf(d), 1);
			showBoard(obj);
			
		}

	
	// Function to calculate the movement of Bishop 
	
	public static void moveBishop(ChessBoard obj, int i, int j, ArrayList<String> alphabets,
			 ArrayList<Integer> numbers)
	{

		
		int count = 0;
		HashMap<Integer, String> hm = new HashMap<Integer, String>();

	    int temp1=i;
	    int temp2=j;
	    
	// to calculate diagonal movement of bishop 
	// to calculate the lower left diagonal 
	
	while(i<=7 && j<=7)
	{
	
			if (obj.board[i++][j++]!=1 && j<=7 && i<=7) // increment both row and column value
			{
				System.out.println("Possible position to move the bishop  diagonally are :" + count + ": "
						+ numbers.get(i) + alphabets.get(j));
				hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
				count++;
				
			}
	}
	
	// to calculate the upper left diagonal 

	i= temp1;
	j= temp2;
			
	while(i>=0 && j>=0)
	{
		if(obj.board[i--][j--]!=1 && j>=0 && i>=0)  //decrement both row and column value
		{
			System.out.println("Possible position to move the bishop diagonally are :" + count + ": "
					+ numbers.get(i) + alphabets.get(j));
			hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
			count++;
		}
	}
	
	// to calculate the upper right diagonal
			
	i=temp1;
	j=temp2;
	
	while(i>=0 && j<=7)
	{
		if( obj.board[i--][j++]!=1 && j<=7 && i>=0) // decrement row & increment column value
		{
			System.out.println("Possible position to move the bishop  diagonally are :" + count + ": "
					+ numbers.get(i) + alphabets.get(j));
			hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
			count++;
		}
	}
	
	
	// to calculate the lower right diagonal
	i=temp1;
	j=temp2;
	
	while(i<=7 && j>=0)
	{
		if(obj.board[i++][j--]!=1 && j>=0 && i<=7) // increment row & decrement column value
		{
			System.out.println("Possible position to move the bishop  diagonally are :" + count + ": "
					+ numbers.get(i) + alphabets.get(j));
			hm.put(count, String.valueOf(numbers.get(i)) + alphabets.get(j));
			count++;
		}
	}
	
	
    System.out.println("Select the position number " + hm.keySet() + " you want the Bishop to move to : ");

		Scanner sc = new Scanner(System.in);

		int z = sc.nextInt();
		System.out.println("You have choosen to move the Bishop to this position :" + hm.get(z));
		String[] x = hm.get(z).split("");
		int b = Integer.parseInt(x[0]);
		String d = x[1];
		
		// making the new position of the bishop as 1
		obj.board[b - 1][alphabets.indexOf(String.valueOf(d))] = 1;
		positionMap.put(String.valueOf(b) + String.valueOf(d), 1);
		showBoard(obj);
	

}

// Function to display the chess board 
	public static void showBoard(ChessBoard obj) 
	{
		int BOARD_SIZE = 8;

		for (int row = 0; row < BOARD_SIZE; row++) 
		{
			System.out.println("");

			for (int column = 0; column < BOARD_SIZE; column++) 
			{
				System.out.print(obj.board[row][column] +"|");
				
			}
            System.out.println("");
		}
		
		System.out.println();

	}
	
	
	
public static void main(String args[])
{
		ChessBoard obj = new ChessBoard();

	// 	showBoard(obj);
		Scanner sc = new Scanner(System.in);

		// ArrayList to store the column values 
		ArrayList<String> alphabets = new ArrayList<String>();
		alphabets.add("a");
		alphabets.add("b");
		alphabets.add("c");
		alphabets.add("d");
		alphabets.add("e");
		alphabets.add("f");
		alphabets.add("g");
		alphabets.add("h");
		
		// ArrayList to store the row values 
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		numbers.add(4);
		numbers.add(5);
		numbers.add(6);
		numbers.add(7);
		numbers.add(8);
		
		boolean continueFlag = true;
		while (continueFlag) {
			System.out.println("You can select one piece from the following :"
					+ " 1.Pawn 2. Queen 3.King 4.Knight 5.Rook 6.Bishop");

			int v = sc.nextInt();
			System.out.println("Enter the position of the chess piece");
			String[] x;
			String d;
			String b;

			String input = sc.next();
			x = input.split("");
			b = x[0];
			d = x[1];
			int b1 =Integer.parseInt(b);

			switch (v) {
			case 1:

				if (positionMap.get(input) == null || positionMap.get(input) != 1)
				{

					System.out.println("You have chosen to move Pawn");
					movePawn(obj, numbers.indexOf(b1), alphabets.indexOf(String.valueOf(d)), alphabets,numbers);
					break;
				} 
				else 
				{
					System.out.println("The position is filled by another player, Please enter another position");
					break;
				}

			case 2:
				
				if (positionMap.get(input) == null || positionMap.get(input) != 1) 
				{
					System.out.println("You have chosen to move Queen:");
					moveQueen(obj, numbers.indexOf(b1), alphabets.indexOf(String.valueOf(d)), alphabets,numbers);

					break;
				} 
				else 
				{
					System.out.println("The position is filled by another player, Please enter another position");
					break;
				}

			case 3:

				if (positionMap.get(input) == null || positionMap.get(input) != 1) 
				{

					System.out.println("You have chosen to move King ");
					moveKingFoward(obj, numbers.indexOf(b1), alphabets.indexOf(String.valueOf(d)), alphabets,numbers);
					break;
				} 
				else
				{
					System.out.println("The position is filled by another player, Please enter another position");
					break;
				}
				
				
			case 4:

				if (positionMap.get(input) == null || positionMap.get(input) != 1)
				{

					System.out.println("You have chosen to move Knight ");
					moveKnight(obj, numbers.indexOf(b1), alphabets.indexOf(String.valueOf(d)), alphabets,numbers);
					break;
				} 
				else
				{
					System.out.println("The position is filled by another player, Please enter another position");
					break;
				}
				
				
			case 5:

				if (positionMap.get(input) == null || positionMap.get(input) != 1)
				{

					System.out.println("You have chosen to move Knight ");
					moveRook(obj, numbers.indexOf(b1), alphabets.indexOf(String.valueOf(d)), alphabets,numbers);
					break;
				} 
				else
				{
					System.out.println("The position is filled by another player, Please enter another position");
					break;
				}
				
			case 6:

				if (positionMap.get(input) == null || positionMap.get(input) != 1)
				{

					System.out.println("You have chosen to move Bishop ");
					moveBishop(obj, numbers.indexOf(b1), alphabets.indexOf(String.valueOf(d)), alphabets,numbers);
					break;
				} 
				else
				{
					System.out.println("The position is filled by another player, Please enter another position");
					break;
				}
				
				
				default :
					
					System.out.println("Please choose a valid option" );
					break;
			}
			
			System.out.println("Do you want to continue : Y or N");
			String flag = sc.next();
			if (!"Y".equalsIgnoreCase(flag)) 
			{
				continueFlag = false;
			}

		}
		System.out.println("Thank you for playing.. Have a nice day!!");
	}

}






	























