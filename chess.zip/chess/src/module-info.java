/**
 * 
 */
/**
 * @author sheka
 *
 */
module chess {
	requires jdk.compiler;
}