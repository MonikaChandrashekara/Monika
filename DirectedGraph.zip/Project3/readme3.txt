READ ME FILE : PROJECT 3


The class is : DirectedGraph 

PLEASE NOTE :This is how to format to input the weighted graph in the form of an adjacency matrix .

suppose the number of vertices is : 4 
then a 4*4 matrix is created 
the vertices start from 0 to V-1 .

sample input :
0 2 1 0
0 0 4 0
5 0 0 6
0 0 0 3

There in the sample input : each value in the matrix represents the weight of the edge that
connects two vertices , suppose there is no edge between two vertices please enter 0 as the value.



DataStructures used in the program :

1) ArrayList: is used to store the list of vertices present in the graph .

2) 2D Array : is used to store the weighted graph .

3) LinkedList : List used to store the adjacent vertices to a given vertex.

4) 1D Array: is used to store the shortest distance from a given source vertex to all the other vertices in the graph.



How to run the program :

Step 1:
Execute the DirectedGraph.java class
Step 2:
enter the number of vertices 
Step 3:
enter the weighted graph
sample input :
0 2 1 0
0 0 4 0
5 0 0 6
0 0 0 3
Step 4 :
Pick a valid option
Step 5 :
the results are displayed



The different methods in this program are :

1) createDiGraph() 
this function is used to create the directed graph by using an adjacent list to keep track of the vertices list.
it also uses an adjacenct matrix to store the weights for the graph.

2) DFS()
This function inturn calls the DFSrecur() function to do DFS traversal.

3) DFSrecur()
Takes the inputed vertex and marks it as visited and perform DFS traversal for each vertex in the graph recursively.

4)BFS()
This function does the traversal of the graph throgh level order traversal.
The vertices are added in the queue , and the traversal is done for the vertices in the queue accordingly.

5)print()
function used to display the elements of the graph 

6)isBipartite()
function to check if the graph is bipartite or not

7)dijkstra_algorithm()
this function prints the shortest path from a given vertex to all the other vertices in the graph.
Incase a vertex is not reachable from a source vertex then the MaxInteger Values is printed for the distance to the destination vertex , this indicated that the destination vertex is not reachable from the given source vertex.

8)Cyclic()
This function calls the isCyclicRecur() function 

9)isCyclicRecur()
This function is a recursive function.

10)isTree()
This function calls the isCyclicUtil function
To be a tree the graph should be acyclic and all the vertices should be reachable from one vertex to another.

11)isCyclicRecur()
This function determines if the graph has a cycle or not.

12)Main()
This contains all the switch cases 
















