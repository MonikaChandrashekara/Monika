

import java.util.*;


public class DirectedGraph 
{
	// number of vertices in the graph
    private static int V; 
    
    // arraylist to store vertices in graph
    private static ArrayList<Integer> verticesList =new ArrayList<>();
    
    // List used to store the adjacent vertices to a given vertex
    private static List<List<Integer>> adj;
    
    // 2D matrix to store the weighted graph
    private static int [][] adjacencyMatrix;
    
    
    // array to store the distances to the vertices .
    private static int distances[];
    
    //List used to store the adjacent vertices to a given vertex
    private static LinkedList<Integer> adjList[];

    private static int pa[]; // Array to store the predesscor 
    
    
    // constructor
    public DirectedGraph(int V)
    {
        this.V = V;
        
        adj = new ArrayList<>(V);
        for (int i = 0; i < V; i++)
         adj.add(new LinkedList<>());
        
        adjList = new LinkedList[V];
        for (int i = 0; i < V; ++i)
        adjList[i] = new LinkedList();
        
        
         adjacencyMatrix = new int[V][V];
        
        
    }
    
    // function to print adjacent list of vertices 
    void print()
   	{
   		for( int v=0;v< V ;v++)
   		{
   			System.out.println("Adjacency list of vertex "+ v); 
               System.out.print("head"); 
               for(Integer pCrawl: adjList[v])
               { 
                   System.out.print(" -> "+pCrawl); 
               } 
               System.out.println("\n"); 
   		}
   	} 
    
    
    // function for BFS traversal 
    void BFStraversal(int s, ArrayList<Integer> values) 

    {
            // Mark all the vertices as not visited
            boolean visited[] = new boolean[V];

           
            LinkedList<Integer> queue = new LinkedList<Integer>();

           // Mark the current vertex as visited and enqueue that vertex
            visited[s] = true;
            queue.add(s);

            while (queue.size() != 0) {
                // Dequeue a vertex from queue and print it
                s = queue.poll();
                System.out.println(values.get(s) +" ");
       
                // Get all adjacent vertices of the dequeued vertex s
                // If a adjacent has not been visited, then mark it
                // visited and enqueue it
                Iterator<Integer> i = adjList[s].listIterator();
                while (i.hasNext()) {
                    int n = i.next();
                    if (!visited[n]) {
                        visited[n] = true;
                        queue.add(n);
                    }
                }
            }
            
            
        }
    

    
    void DFS(int v)
    {
        // Mark all the vertices as not visited(set as
        // false by default in java)
        boolean visited[] = new boolean[V];

        // Call the recursive helper function to print DFS traversal
        DFSrecur(v, visited);
    }
    
    // recursive function for DFS traversal 
    void DFSrecur(int v,boolean visited[])
    {
        // Mark the current node as visited and print it
        visited[v] = true;
        System.out.println(v+" ");

        // Recur for all the vertices adjacent to this vertex
        Iterator<Integer> i = adjList[v].listIterator();
        while (i.hasNext())
        {
            int n = i.next();
            if (!visited[n])
                DFSrecur(n, visited);
        }
    }

  
   
  // function to create a directed graph   
private static int[][] createDiGraph(Scanner in)
    
    {
     
        if(V>0)
        {
            for (int i = 0; i < V; i++) {
               
                try 
                {
                    verticesList.add(i);
                }
                catch (InputMismatchException e)
                {
                    System.out.println("Invalid Input");
                }

            }
      
            System.out.println("Enter the  weighted graph in the form of Adjacency matrix:");
            
            // taking  the input in the form of an adjacency matrix 
            for (int i = 0; i < V; i++) 
            {
                for (int j = 0; j < V; j++)
                {
                    int temp = in.nextInt();
                    
                    // to check for negative values 
                    if (temp > 0) 
                    {
                        
                         	adjacencyMatrix[i][j] = temp;
                          
                            addEdge(i, j);
                    }

                }
            }
            System.out.println(" The Directed Graph is created  : The vertices  are from 0 through" +" " +(V-1));
            
            return adjacencyMatrix;
        }
        else
        {
            System.out.println("Invalid Input");
            createDiGraph(in);
            return null;
        }
    }

    // function to insert an edge in the graph 
    static void addEdge(int source, int dest) 
    {
        adj.get(source).add(dest);
        adjList[source].add(dest);

     }
       
    
    
    // function to check for bipartite graph 
   
    private static boolean isBipartite(int G[][],int src)
    {
        // Create a color array to store
        // colors assigned to all vertices.
        // Vertex number is used as index
        // in this array. The value '-1'
        // of colorArr[i] is used to indicate
        // that no color is assigned
        // to vertex 'i'. The value 1 is
        // used to indicate first color
        // is assigned and value 0 indicates
        // second color is assigned.
        int colorArr[] = new int[V];
        for (int i=0; i<V; ++i)
            colorArr[i] = -1;

        // Assign first color to source
        colorArr[src] = 1;

        // Create a queue (FIFO) of vertex numbers
        // and enqueue source vertex for BFS traversal
        LinkedList<Integer> q = new LinkedList<Integer>();
        q.add(src);

        // Run while there are verticesList in queue (Similar to BFS)
        while (q.size() != 0)
        {
            // Dequeue a vertex from queue
            int u = q.poll();

            // Return false if there is a self-loop
            if (G[u][u] == 1)
                return false;

            // Find all non-colored adjacent verticesList
            for (int v=0; v<V; ++v)
            {
                // An edge from u to v exists
                // and destination v is not colored
                if (G[u][v]==1 && colorArr[v]==-1)
                {
                    // Assign alternate color to this adjacent v of u
                    colorArr[v] = 1-colorArr[u];
                    q.add(v);
                }

                // An edge from u to v exists and destination
                //  v is colored with same color as u
                else if (G[u][v]==1 && colorArr[v]==colorArr[u])
                    return false;
            }
        }
        // If we reach here, then all adjacent verticesList can
        // be colored with alternate color
        return true;
    }

 
    
 // function for dijkstar's algorithm 
    
    public  void dijkstra_algorithm(int source)
    {
        distances = new int[V];
        pa= new int[V];
        

        Boolean sptSet[] = new Boolean[V];
        for (int i = 0; i < V; i++)
        {
            distances[i] = Integer.MAX_VALUE;
            sptSet[i] = false;
            pa[i]=-1;
        }

        // Distance of source vertex from itself is always 0
        distances[source] = 0;
      

        // Find shortest path for all verticesList
        for (int count = 0; count < V - 1; count++) 
        {
            // Pick the minimum distance vertex from the set of verticesList
            // not yet processed. u is always equal to src in first
            // iteration.
            int u = minDistance(distances, sptSet);

            // Mark the picked vertex as processed
            sptSet[u] = true;

            // Update dist value of the adjacent verticesList of the
            // picked vertex.
            for (int v = 0; v < V; v++)

                // Update dist[v] only if is not in sptSet, there is an
                // edge from u to v, and total weight of path from src to
                // v through u is smaller than current value of dist[v]
                if (!sptSet[v] && adjacencyMatrix[u][v] != 0 &&
                        distances[u] != Integer.MAX_VALUE &&
                        distances[u] + adjacencyMatrix[u][v] < distances[v])
                {
                    distances[v] = distances[u] + adjacencyMatrix[u][v];
                    pa[v]=u;
                   
                }
        }
    }

    private  int minDistance(int dist[], Boolean sptSet[])
    {
        // Initialize min value
        int min = Integer.MAX_VALUE, min_index=-1;

        for (int v = 0; v < V; v++)
            if (!sptSet[v] && dist[v] <= min)
            {
                min = dist[v];
                min_index = v;
            }

        return min_index;
    }

    
    
    // recursive program to check for cycle in a graph 
    static boolean isCyclicRecur(int i, boolean[] visited,
                         boolean[] rS)
    {

        // Mark the current node as visited and
        // part of recursion stack
        if (rS[i])
            return true;

        if (visited[i])
            return false;

        visited[i] = true;

        rS[i] = true;
        List<Integer> children = adj.get(i);

        for (Integer c: children)
            if (isCyclicRecur(c, visited, rS))
                return true;

        rS[i] = false;

        return false;
    }

   
    static boolean Cyclic()
    {

        // Mark all the verticesList as not visited and
        // not part of recursion stack
        boolean[] visited = new boolean[V];
        boolean[] rS = new boolean[V];


        // Call the recursive helper function to
        // detect cycle in different DFS trees
        for (int i = 0; i < V; i++)
            if (isCyclicRecur(i, visited, rS))
                return true;

        return false;
    }

 
    Boolean isCyclicUtil(int v, Boolean visited[], int parent)
    {
        // Mark the current node as visited
        visited[v] = true;
        Integer i;

        // Recur for all the vertices adjacent to this vertex
        Iterator<Integer> it = adjList[v].iterator();
        while (it.hasNext())
        {
            i = it.next();

            // If an adjacent is not visited, then recur for
            // that adjacent
            if (!visited[i])
            {
                if (isCyclicUtil(i, visited, v))
                    return true;
            }

            // If an adjacent is visited and not parent of
            // current vertex, then there is a cycle.
            else if (i != parent)
                return true;
        }
        return false;
    }

    // Returns true if the graph is a tree, else false.
    Boolean isTree()
    {
        // Mark all the vertices as not visited and not part
        // of recursion stack
        Boolean visited[] = new Boolean[V];
        for (int i = 0; i < V; i++)
            visited[i] = false;

        // The call to isCyclicUtil serves multiple purposes
        // It returns true if graph reachable from vertex 0
        // is cyclcic. It also marks all vertices reachable
        // from 0.
        if (isCyclicUtil(0, visited, -1))
            return false;

        // If we find a vertex which is not reachable from 0
        // (not marked by isCyclicUtil(), then we return false
        for (int u = 0; u < V; u++)
            if (!visited[u])
                return false;

        return true;
    }
    
    
 
    
    
    
    
    
    
    
    
    
    
    
    
    
   
    // main method 
    
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter the total number of vertices in the graph:");
        V = in.nextInt();
        
        DirectedGraph directedGraph = new DirectedGraph(V);
        
       
        
        while (true)
        {
          
        System.out.println("Please choose the operations to perform:");
      	System.out.println("[1]Create a Directed Graph using the inputs taken from console");
      	System.out.println("[2]Perform DFS traversal on the graph");
      	System.out.println("[3]Perform BFS traversal on the graph ");
      	System.out.println("[4]Find Shortest Path from Source to all verticesList using Dijkstra�s shortest path Algorithm");
      	System.out.println("[5]Detect if there is a Cycle in the graph");
      	System.out.println("[6]Detect if the graph is bipartite or not");
      	System.out.println("[7]Check if Graph is a tree or not");
      	System.out.println("[8]Exit  the operations");

      	
      	try
      	{
            int numb = in.nextInt();
            if(numb>0) {
                // Switch expression
                switch (numb) {
                    
                    case 1:
                        adjacencyMatrix = createDiGraph(in);
                    
                        directedGraph.print();
                        break;
                    case 2:
                        System.out.println("");
                       
                        System.out.println("Enter the starting vertex for DFS traversal :");
                        System.out.print("The vertices start from 0, pick values between 0 and "+ (V-1));
                      
                        int s = in.nextInt();
                        
                        System.out.println("Depth First Traversal for the graph  :");
                        try {
                           
                           directedGraph.DFS(s);
                        }
                        catch (InputMismatchException e)
                        {
                            System.out.println("Invalid Input");
                        }

                        break;
                    case 3:
                        System.out.println("");
                        
                        System.out.println("Enter the starting vertex for BFS traversal:");
                        System.out.print("The vertices start from 0, pick values between 0 and "+ (V-1));
                        
                        int s1 = in.nextInt();
                        
                        System.out.println("Breadth First Traversal  for the graph :");
                        try
                        {
                           
                            directedGraph.BFStraversal(s1, verticesList);
                        }
                        catch (InputMismatchException e)
                        {
                            System.out.println("Invalid Input");
                        }
                        break;
                        
                    case 4:
                        try 
                        {
                            System.out.println(" Please Enter the source vertex :");
                            System.out.print(" The vertices start from 0, pick values between 0 and "+ (V-1));
                            int s2 = in.nextInt();
                          directedGraph.dijkstra_algorithm(s2);
                            
                            System.out.println("The shortest path to all nodes are");
                            for (int i = 0; i <= distances.length - 1; i++)
                            {
                            	
                            	int p=pa[i];
                            	if(distances[i]==Integer.MAX_VALUE)
                            	{
                            		System.out.println(s2 +" " +"to" +" " +verticesList.get(i)  + " "+ "is no path found");
                            	}
                            		
                            	else if(distances[i]==0 && p==-1)
                            	{
                            	System.out.println(s2 +" " +"to" +" " +verticesList.get(i)  + " "+ "is"  + " "+distances[i] );
                            	System.out.println("This is the source node : no predecessor" );
                            	
                            	}
                            	else
                            	{
                            		System.out.println(s2 +" " +"to" +" " +verticesList.get(i)  + " "+ "is"  + " "+distances[i] );
                                	System.out.println("The predecessor for"  + " "+verticesList.get(i)  + " "+"is" +" " +p);
                            	}
                               
                            }
                            


                        } catch (InputMismatchException inputMismatch) {
                            System.out.println("Wrong Input Format");
                        }
                        
                    
                        
                        break;
                        
                    case 5:
                        if (Cyclic())
                            System.out.println("Graph contains cycle");
                        else
                            System.out.println("Graph does not " + "contain cycle");
                        break;
                        
                    case 6:
                        if (isBipartite(adjacencyMatrix, 0)) 
                        {
                            System.out.println("Yes the graph  is a Bipartite");
                        } 
                        else 
                        {
                            System.out.println("No the graph  is not Bipartite");
                        }
                        break;
                        
                    case 7:
                       
                        if(directedGraph.isTree())
                        	System.out.println("Graph is  a Tree");
                        else
                        	 System.out.println("Graph is not a Tree");
                        
                        break;
                        
                        
                        
                    case 8:
                        System.exit(0);
                        
                    default:
                        System.out.println("Please choose a valid option");
                }
            }
            else
            {
                System.out.println("Invalid Input");
            }
      	}
      	catch(InputMismatchException e)
      	{
      		System.out.println("Please enter a valid input");
      	}

        }



    }

   

}
