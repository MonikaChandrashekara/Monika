package treepackage;


// Defining a class Node
public class Node 
{
	private String data; 
	private Node leftNode; 
	private Node rightNode;
	private int height;
 
	// Constructor for assigning the string value to data variable
	public Node(String data) 
	{
		this.data = data;
	}
 
	// getter and setters for key value of a node
	public String getData() 
	{
		return data;
	}
 
	public void setData(String data) 
	{
		this.data = data;
	}
 // getter and setter method for left child
	public Node getLeftNode() 
	{
		return leftNode;
	}
 
	public void setLeftNode(Node leftNode)
	{
		this.leftNode = leftNode;
	}
 
	// getter and setter method for right child
	public Node getRightNode()
	{
		return rightNode;
	}
 
	public void setRightNode(Node rightNode) 
	{
		this.rightNode = rightNode;
	}
 
	// getter and setter method for the height of the tree
	public int getHeight() 
	{
		return height;
	}
 
	public void setHeight(int height)
	{
		this.height = height;
	}
 
	@Override
	public String toString() 
	{
		return "" + this.data;
	}
	
	
}