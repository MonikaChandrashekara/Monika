package treepackage;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class RunAvlTree
{
	
	public static void main(String[] args) {
		 
		Tree avl = new AvlTree();	
		Scanner sc= new Scanner(System.in);
		boolean continueFlag = true;
		while(continueFlag)
		{
		System.out.println("Please choose the operations to perform:");
		System.out.println("[1]Create a Balanced Binary Serach Tree");
		System.out.println("[2]Display the elements of BST");
		System.out.println("[3]Insert an  element to BST");
		System.out.println("[4]Delete an element from the tree");
		System.out.println("[5]Find the Length of the tree");
		System.out.println("[6]Find if BST is a Max Heap");
		System.out.println("[7]The Anagram count for BST");
		

		int k = sc.nextInt();
		switch(k)
		{
			case 1:
		         
				 System.out.println("Enter the NUMBER of strings to be inserted");
                 int n=sc.nextInt();
                 String[] elements = new String[n];
             
                 System.out.println("enter the strings to be inserted");
                
                 for(int i=0;i<n;i++)
       	         elements[i]=sc.next();
       	        
                 for (int i = 0; i < elements.length; i++)
                 avl.insert(elements[i]);
                
                 break;
                 
			case 2:
		          
		           avl.traverse(); 
		           break;
		           
			case 3 :
				System.out.println("enter a string to be inserted");
				String m= sc.next();
				avl.insert(m);
				break;
				
			case 4:
				System.out.println("please enter the string to be deleted");
				String v= sc.next();
				avl.delete(v);
				break;
				
			case 5 :
				avl.findHeight();
				break;
				
			case 6:
				avl.findHeap();
				break;
				
			case 7:
				avl.findAnagram();
				break;
				
		 default:
			     System.out.println(" Please pick a valid option");
			     break;
		} 
		System.out.println("Do you want to continue : Y or N");
		String flag = sc.next();
		if (!"Y".equalsIgnoreCase(flag))
		{
			continueFlag = false;
		}
		} 
		
	}
}




