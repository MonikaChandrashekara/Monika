package treepackage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

//  AVL class implements Tree Interface

public class AvlTree implements Tree
{
 
	private Node root;
	 ArrayList<String> ele = new ArrayList<String>();
	 
 
	 // Insert method : to add strings to the tree 
	@Override
	public void insert(String data) 
	{
		ele.add(data);
		root = insert(root, data);
		
	}
 
	// traverse method : to display elements of the tree
	@Override
	public void traverse()
	{
		if (root == null)
			return;
 
		System.out.println(" Displaying the elements through inorder traversal from root node [" + root.getData() + "]  :");
		inOrderTraversal(root);
	}
 
	// delete method : to remove strings from the tree 
	@Override
	public void delete(String data) 
	{
		root = delete(root, data);
	}
 
	// over-riding insert method 
	private Node insert(Node node, String data) 
	{
		// base condition : when tree is empty
		if (node == null)
		{
			System.out.println("insert [" + data + "]");
			return new Node(data);
		}
 
		// if string to insert is less than root key , insert to left of tree
		if (data .compareTo(node.getData())<0)
		{
			node.setLeftNode(insert(node.getLeftNode(), data));
		} 
		
		// if string to insert is greater than root key, insert to right of tree
		else 
		{
			node.setRightNode(insert(node.getRightNode(), data));
		}
 
		node.setHeight(Math.max(height(node.getLeftNode()), height(node.getRightNode())) + 1);
		
		// for each insertion check the balance and rotate if required
 
		return checkBalanceAndRotate(data, node);
	}
 
	private Node delete(Node node, String data)
	{
		if (node == null)
			return node;
 
		if (data.compareTo(node.getData())<0)
		{ // go to the left recursively if the string to  be deleted is less than root key
			node.setLeftNode(delete(node.getLeftNode(), data));
		} 
		else if (data.compareTo(node.getData())>0) 
		{ // go to the right recursively if the string to be deleted is greater than root key
			node.setRightNode(delete(node.getRightNode(), data));
		} 
		else 
		{ //  if the root string to be deleted is the root node / the node with two children
 
			if (node.getLeftNode() == null && node.getRightNode() == null) 
			{
				System.out.println("removed the  node [" + node.getData() + "]");
				return null;
			}
 
			if (node.getLeftNode() == null) 
			{
				System.out.println("removed the node [" + node.getData() + "]");
				Node tempNode = node.getRightNode();
				node = null;
				return tempNode;
			} 
			else if (node.getRightNode() == null) 
			{
				System.out.println("removed the  node [" + node.getData() + "]");
				Node tempNode = node.getLeftNode();
				node = null;
				return tempNode;
			}
 
			System.out.println("removed node with two children");
			Node tempNode = getPredecessor(node.getLeftNode());
 
			//System.out.println("replaced with Predecessor [" + tempNode.getData() + "]");
			node.setData(tempNode.getData());
			node.setLeftNode(delete(node.getLeftNode(), tempNode.getData()));
		}
 
		node.setHeight(Math.max(height(node.getLeftNode()), height(node.getRightNode())) + 1);
 
		// have to check on every delete operation whether the tree has become
		// unbalanced or not 
		return checkBalanceAndRotate(node);
	}
 
	private void inOrderTraversal(Node node)
	{
		// displaying the elements in-order : <left><root><right>
		if (node.getLeftNode() != null)
			inOrderTraversal(node.getLeftNode());
 
		System.out.println(node);
		
		if (node.getRightNode() != null)
			inOrderTraversal(node.getRightNode());
	}
 
	private Node checkBalanceAndRotate(String data, Node node) 
	{
		int balance = getBalance(node); // balance = leftNode.height - rightNode.height
										
 
		// left-left  sub tree is heavy : right-rotate on root
		if (balance > 1 && data .compareTo(node.getLeftNode().getData())<0)
		{
			return rightRotation(node);
		}
 
		// right-right  sub tree is heavy : left-rotate on root 
		if (balance < -1 && data.compareTo(node.getRightNode().getData())>0)
		{
			return leftRotation(node);
		}
 
		// left-right sub tree is heavy : left rotate on parent and right rotate on grandparent node 
		if (balance > 1 && data.compareTo(node.getLeftNode().getData())>0)
		{
			node.setLeftNode(leftRotation(node.getLeftNode()));
			return rightRotation(node);
		}
 
		// right-left sub tree is heavy : right rotate on parent and left rotate on grandparent node
		if (balance < -1 && data.compareTo(node.getRightNode().getData())<0) 
		{
			node.setRightNode(rightRotation(node.getRightNode()));
			return leftRotation(node);
		}
 
		return node;
	}
 
	private Node checkBalanceAndRotate(Node node) 
	{
		int balance = getBalance(node);
 
		// left heavy -> left-right heavy or left-left heavy
		if (balance > 1)
		{
			// if left-right: left rotation before right rotation
			if (getBalance(node.getLeftNode()) < 0)
			{
				node.setLeftNode(leftRotation(node.getLeftNode()));
			}
 
			// left-left
			return rightRotation(node);
		}
 
		// right heavy -> left-right heavy or right-right heavy
		if (balance < -1)
		{
			// if right-left: right rotation before left rotation
			if (getBalance(node.getRightNode()) > 0)
			{
				node.setRightNode(rightRotation(node.getRightNode()));
			}
 
			// right-right
			return leftRotation(node);
		}
 
		return node;
	}
 
	
	// rightRotation method on grandparent node : middle node becomes parent and the root node becomes right child 
	private Node rightRotation(Node node)
	{
		
		Node newParentNode = node.getLeftNode();
		Node mid = newParentNode.getRightNode();
 
		newParentNode.setRightNode(node);
		node.setLeftNode(mid);
 
		node.setHeight(Math.max(height(node.getLeftNode()), height(node.getRightNode())) + 1);
		newParentNode
				.setHeight(Math.max(height(newParentNode.getLeftNode()), height(newParentNode.getRightNode())) + 1);
 
		return newParentNode;
	}
 
	// leftRotation on grandparent node : the middle node becomes the new parent and the root node becomes left child
	private Node leftRotation(Node node) 
	{
		
		Node newParentNode = node.getRightNode();
		Node mid = newParentNode.getLeftNode();
 
		newParentNode.setLeftNode(node);
		node.setRightNode(mid);
 
		node.setHeight(Math.max(height(node.getLeftNode()), height(node.getRightNode())) + 1);
		newParentNode
				.setHeight(Math.max(height(newParentNode.getLeftNode()), height(newParentNode.getRightNode())) + 1);
 
		return newParentNode;
	}
 
	// Balance function : determines the  difference in height of left sub tree and right sub tree 
	private int getBalance(Node node)
	{
		if (node == null)
		{
			return 0;
		}
		return height(node.getLeftNode()) - height(node.getRightNode());
	}
 
	// function to determine height 
	private int height(Node node)
	{
 
		if (node == null) {
			return -1;
		}
 
		return node.getHeight();
	}
 
	// method used during deletion to replace the parent node with its right subtree's  element 
	private Node getPredecessor(Node node) 
	{
 
		Node predecessor = node;
 
		while (predecessor.getRightNode() != null)
			predecessor = predecessor.getRightNode();
 
		return predecessor;
	}
	
@Override
public void findHeight()
{
	 int a1=findHeight(root);
	if(a1!=-1)
		System.out.println("The height of the balanced tree is :"+a1);
	else
		System.out.println("The height of the tree is -1 as it is a empty tree");
}

// function to determine length of tree 	
private	int findHeight(Node node) 
	{

	    if (node == null)
	    {
	       return -1;
	    }
	    
// recursively find height of left & right sub tree 
	    int lh = findHeight(node.getLeftNode());
	    int rh = findHeight(node.getRightNode());

	    // if left sub tree length is greater return that else return the right sub tree length
	    if (lh > rh)
	    {
	        return lh+1;
	         
	    } 
	    else
	    {
	        return  rh+1;
	      
	        
	    }
	}


@Override
public void findHeap()
{
	
	
	boolean b1 =findHeap(root);
	
	if(b1==true)
	System.out.println(" The BST is Max Heap");
	
	else
		System.out.println("The BST is not a Max Heap");
}

private boolean findHeap(Node node)
{
	
// if only one node : its is a max heap 
	if(node.getLeftNode()==null && node.getRightNode()==null)
		return true;
	
	// if only two nodes : with no right sub tree , just the root node and left sub tree , it is a max heap
	if(node.getRightNode()==null)
	{
		return (node.getData().compareTo(node.getLeftNode().getData())>=0);
	}
	
	else // in all other cases : not a max heap 
	{
	if((node.getData().compareTo(node.getLeftNode().getData())>=0) && (node.getData().compareTo(node.getRightNode().getData())>=0))
	 
		return findHeap(node.getLeftNode()) && findHeap(node.getRightNode());
	else
		
	return false;
	}
	
}

// function to find the anagaram count

public void  findAnagram()
{
	 HashMap<String, Integer> frequency = new HashMap<>();
	 
	for(String s1 :ele)
	{
		int count=0;
		System.out.println("Anagram Count of "+s1+" is :");
		
		for(String s2 :ele)
		{
			// converting the strings to upper case 
			String st1 = s1.toUpperCase(); 
			String st2 = s2.toUpperCase();
			
			// splitting each character of the string into an array 
			char[] st1_chars=st1.toCharArray();
			char[] st2_chars=st2.toCharArray();
			
			// sorting the arrays 
			Arrays.sort(st1_chars);
			Arrays.sort(st2_chars);
			
			// comparing the elements of the array 
			if(Arrays.equals(st1_chars , st2_chars))
			{
				count++;
			}
			
		}
		System.out.println(count-1);		
	}
		
		
	}
	 
	
}

	







