package treepackage;

import java.util.ArrayList;

// Interface tree implemented by AVLTree class 
public interface Tree 
{
	public void insert(String data);
	public void traverse();
	public void delete(String data);
	public void findHeight();
	public void findHeap();
	public void findAnagram();
	
}
