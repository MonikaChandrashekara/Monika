package week1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Scanner;

public class Project2 {
static String longest_subarray;
static int subarray_length;

int partition(int a[], int start , int end) // this function helps to fix the pivot element and partition the elements
	{
		int pivot= a[end];
		int index=start; 
		for (int i=start; i<end; i++)
		{
			if(a[i]<=pivot) // if the element is lesser that the pivot swap it with the element at the partition index
			{
				int temp= a[i];
				a[i]=a[index];
				a[index]=temp;
				index=index+1; // incrementing the partition index.
			}
		}
		int	r=a[index]; // swap the pivot element with the element at the partition index
		a[index]=a[end];
		a[end]=r;
		return index;
	}
void sort (int a[], int start , int end) // Function to recursively sort the array
	{
		if(start<end)
		{
			int pindex= partition(a, start,end);
			sort(a,start,pindex-1); // recursively sort the left half of the array
			sort(a, pindex+1,end); // recursively sort the right half of the array
			
		}
	}


	
static int med(int a[]) // Function to find the median of the array
{
	
	int n=a.length;
	int mid = n/2; // The total number of elements divided by 2 gives the middle element of the array.
	
	if(n%2!=0)
	{
		return a[mid]; // If the array has odd number of elements return the middle element as median
	}
	else
	{
		return (a[mid]+a[mid-1])/2; //If the array has even number of elements then return the middle element and mid-1 element
		
	}
	
}


 void recurseArray(int[] a,int x,int start,int k) // Recursive function to find the Sub-Array
 {
		int n = a.length;
		int median = med(a); // Invoking median function
		if (median>=x) {
			System.out.println("The longest subarray  is "+ Arrays.toString(a));
			System.out.println("The length of the longest subarray is "+a.length);
			longest_subarray = Arrays.toString(a);
			subarray_length = a.length;
			return;
		}
		else {
			
			start=1;
			k-=1; // The array size is decreased with each recursive call to the function.
			
		// If the entire array is traversed then there is no sub-array left to traverse.
			if(start==k) { 
				System.out.println("No Sub Array Found");
				return;
			}
			int array[] = new int[k]; //Creation of a new array with size K ,as each time the array size decreases.
			int y = 0;
			for(int i=start;i<n;i++) {
				array[y++] = a[i];		
			}
			
			recurseArray(array,x,start,k); //the function is called recursively until start is equal to the end
		}
		}

public static void main(String args[])
	{
		
	System.out.println(" Enter the size of the Array");
	Scanner m= new Scanner(System.in); // Object of Scanner class is declared and initialized
		int n=m.nextInt(); // variable to store the size of the array.
		
		int a[] = new int[n]; // Creating an array of type integer and of size n
		
		System.out.println("Enter the elements of the array of size "+n+" ");
		for( int i=0;i<n;i++)
		{
			a[i]=m.nextInt(); // For loop to store the elements of the array as when the user provides input
		}
		
		Project2 z=new Project2(); // creation of an object for the Project2 class
		z.sort(a, 0, n-1); // invoking the sort method using an object
		
		
		System.out.println("Enter the value of x");
		int x = m.nextInt();	// storing the value of X
		//System.out.println(x);
		int start = 0;
		z.recurseArray(a,x,start,n); //Invoking the recurseArray function through a object
		
		System.out.println("Enter the absolute path for the output to be generated..");
		Scanner scan = new Scanner(System.in); // Object of Scanner class is declared and initialized
		String path=scan.next();
		File fileName = new File(path+"Q2_Output.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(fileName));
			String data = "The longest subarray  is "+longest_subarray;
		    writer.write(data);
		    writer.newLine();
			data = "The length of the longest subarray is "+subarray_length;
			writer.write(data);
			writer.newLine();
		    writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
