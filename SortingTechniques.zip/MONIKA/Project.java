package week1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;


public class Project {
	static HashMap<Integer,ArrayList<String>> difference_map = new HashMap<>(); // Difference and the Pair of elements is stored as key-value pair
	static int[] b  ;
	

	
	void insertionsort(int arr[], int n) //Insertion Sort to sort the difference array
	{
		
		 for (int i=1; i<n;i++)
		 {
			int key=arr[i];
			int h=i;
			
			while (h>0 && key<arr[h-1])
			{
				arr[h]=arr[h-1];
				h=h-1;	
			}
			arr[h]=key;
		 }
	}
	
	
	static void print( int a[]) // Print function to print the elements of the array.
	{
		int n=a.length;
		for (int i=0;i<n;i++)
			System.out.println(a[i]+"");
		System.out.println();
	}
	
int partition(int a[], int start , int end) // this function helps to fix the pivot element and partition the elements
	{
		int pivot= a[end];
		int index=start; 
		for (int i=start; i<end; i++)
		{
			if(a[i]<=pivot) // if the element is lesser that the pivot swap it with the element at the partition index
			{
				int temp= a[i];
				a[i]=a[index];
				a[index]=temp;
				index=index+1; // incrementing the partition index.
			}
		}
		int	r=a[index]; // swap the pivot element with the element at the partition index
		a[index]=a[end];
		a[end]=r;
		return index;
	}
void sort (int a[], int start , int end) // Function to recursively sort the array
	{
		if(start<end)
		{
			int pindex= partition(a, start,end);
			sort(a,start,pindex-1); // recursively sort the left half of the array
			sort(a, pindex+1,end); // recursively sort the right half of the array
			
		}
	}
	
	void mini(int a[], int n) // Function to find Minimum elements 
	{	
		
		ArrayList<String> value;
		b= new int[n-1]; 
		int i;
		int k=0;
		for ( i=0; i<=n-2; i++)
		{
			String pair = String.valueOf(a[i])+","+String.valueOf(a[i+1]); // Converting the successive pair of elements to String data type
			int diff = a[i+1]-a[i]; // variable which holds the difference of successive elements
			b[k]=diff; // Storing the difference in an array
			k=k+1;
			if (difference_map.containsKey(diff)) // Checking  if the difference exists in the Hashmap
			{
				value = difference_map.get(diff); // fetching the existing pair of elements for that difference
				ArrayList<String> pairslist = new ArrayList<String>();
				pairslist.add(pair); // Adding both the pair of elements to the list
				value.addAll(pairslist);
				difference_map.put(diff,value); // If the difference exists then adding the  both  pair of successive elements as the value in hashmap.
			}
			else {
				ArrayList<String> value1 = new ArrayList<>(); 
				value1.add(pair); 
				difference_map.put(diff,value1); // Adding the new pair of successive elements as the value and difference as key-value pair
			}	
		}
		
		int l=b.length;
		insertionsort(b,l); // sorting the difference array
		
	}	
public static void main(String args[])
	{
	System.out.println(" Enter the size of the Array");
	Scanner m= new Scanner(System.in);
		int n=m.nextInt(); // variable to store the size of the array.
		
		int a[] = new int[n];
		
		System.out.println("Enter the elements of the array of size "+n+" ");
		for( int i=0;i<n;i++)
		{
			a[i]=m.nextInt();
		}
		Project z=new Project();
		int start=0;
		int end=n-1;
		z.sort(a, start, end);// invoking  quicksort
		System.out.println("Sorted Array");
		print(a);
		z.mini(a,n);	// Invoking the function to find minimum elements
		
		System.out.println("Enter the absolute path for the output to be generated..");
		Scanner scan = new Scanner(System.in); // Object of Scanner class is declared and initialized
		String path=scan.next();
		//System.out.println("the path is "+path);
		File fileName = new File(path+"Q1_Output.txt");
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(fileName));
			String data = "The sorted output is : "+Arrays.toString(a);
		    writer.write(data);
		    writer.newLine();
			data = "First Minimum -- "+ difference_map.get(b[0]) + " -- "+ String.valueOf(b[0]);
			System.out.println(data);
		    writer.write(data);
		    writer.newLine();
			data = "Second Minimum -- ["+ difference_map.get(b[1]).get(0) + "] -- "+ String.valueOf(b[1]);
			System.out.println(data);
			writer.write(data);
			writer.newLine();
		    writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
