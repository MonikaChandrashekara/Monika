/*
Group Number : 27
Group Members:
Monika Chandrashekara - 801074899
Yechan Gunja Sriram - 801136225
Karthik Rangaraj - 801135834


*/


package com.example.pizzastore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class OrderActivity extends AppCompatActivity {

    TextView tv_ToppingPrice;
    TextView tv_dPrice;
    TextView tv_totalPrice;
    TextView tv_tList;
    TextView tv_delivery;

    Button bt_finish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        ArrayList<String> toppings;
        boolean delivery;
        double total_toppingPrice;
        double total_cost;
        double basePrice = 6.50;
        double deliveryPrice;
        String Tlist = "";

        tv_ToppingPrice = findViewById(R.id.tv_toppingPrice);
        tv_dPrice = findViewById(R.id.tv_dPrice);
        tv_totalPrice = findViewById(R.id.tv_totalPrice);
        tv_tList = findViewById(R.id.tv_tList);
        tv_delivery = findViewById(R.id.tv_delivery);
        bt_finish = findViewById(R.id.bt_fn);

        if (getIntent() != null && getIntent().getExtras() != null) {
            toppings = getIntent().getExtras().getStringArrayList(MainActivity.Main_Key);
            delivery = getIntent().getExtras().getBoolean(MainActivity.Sub_Key);

            total_toppingPrice = toppings.size() * 1.50;
            if (toppings.size() > 0) {
                Log.d("topping", "onCreate: " + toppings.size());
                for (String topping : toppings) Tlist += topping + ", ";
                Tlist = Tlist.substring(0, Tlist.length() - 2);

                tv_tList.setText(Tlist);
            }
            if (delivery == true) {
                deliveryPrice = 4.00;
                tv_dPrice.setText("$ "+String.valueOf(deliveryPrice));
            } else {
                deliveryPrice = 0.00;
                tv_dPrice.setVisibility(View.INVISIBLE);
                tv_delivery.setVisibility(View.INVISIBLE);
            }

            total_cost = basePrice + total_toppingPrice + deliveryPrice;

            tv_totalPrice.setText(String.valueOf("$ "+total_cost));
            tv_ToppingPrice.setText(String.valueOf("$ "+total_toppingPrice));


        }
        bt_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OrderActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
