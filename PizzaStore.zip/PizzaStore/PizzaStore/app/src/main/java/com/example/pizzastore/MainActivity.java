
package com.example.pizzastore;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.flexbox.FlexboxLayout;

import java.util.ArrayList;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button bt_topping;
    Button bt_clear;
    Button bt_checkout;
    ImageView iv_pizza;
    CheckBox cb_delivery;

    ArrayList<ImageView> image_topping = new ArrayList<>();

    ImageButton imageButton;

    String[] toppings = {"Bacon", "Cheese", "Garlic", "Green Pepper", "Mushroom", "Olives",
            "Onions", "Red Pepper"};


    ArrayList<String> current_toppings = new ArrayList<String>();


    ProgressBar progressBar;
    int max_progress = 0;


    FlexboxLayout fb;


    public static String Main_Key = "main";
    public static String Sub_Key = "sub";


    View.OnClickListener listener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_topping = findViewById(R.id.bt_topping);
        iv_pizza = findViewById(R.id.iv_pizza);
        iv_pizza.setImageResource(R.drawable.pizza);
        bt_clear = findViewById(R.id.bt_clear);
        bt_checkout = findViewById(R.id.bt_checkout);
        cb_delivery = findViewById(R.id.cb_delivery);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setMax(10);

        fb = findViewById(R.id.flexboxlayout);


// ADD TOPPINGS : ALERT DIALOG
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Choose a Topping");
        builder.setCancelable(true);
        builder.setItems(toppings, new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialogInterface, int i) {

                Log.d("demo", "Selected topping" + toppings[i]);
                String temp = toppings[i];
                Log.d("temp", "onClick: " + temp);
                int viewCount = fb.getChildCount();
                Log.d("count", "onClick: "+viewCount);
                if (viewCount < 10) {
                    current_toppings.add(toppings[i]);
                    progressBar.setProgress(viewCount + 1);
                    int result = display(temp);
                    imageButton = new ImageButton(MainActivity.this);
                    imageButton.setBackgroundResource(result);
                    fb.addView(imageButton);
                    imageButton.setTag(imageButton);
                    imageButton.setId(result);
                } else {

//                    int result=  display(temp);
//                    ImageButton imageButton = new ImageButton(MainActivity.this);
//                    imageButton.setBackgroundResource(result);
//                    fb.addView(imageButton);

                    //   bt_topping.setEnabled(false);

                    //progressBar.setProgress(++max_progress);

                    //  progressBar.setProgress(viewCount + 1);

                    Toast.makeText(MainActivity.this, "Maximum Topping Capacity Reached ", Toast.LENGTH_LONG).show();


                }
                imageButton.setOnClickListener((View.OnClickListener) MainActivity.this);

//                imageButton.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        fb.removeView(view);
//                        int removeView = fb.getChildCount();
//                        progressBar.setProgress(removeView);
//                    }
//                });


            }


        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

            }
        });


        final AlertDialog alert = builder.create();

        findViewById(R.id.bt_topping).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fb.getChildCount()<=9) {
                    alert.show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Maximum Topping Capacity Reached ", Toast.LENGTH_LONG).show();
                }

            }
        });


        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                current_toppings.clear();
                fb.removeAllViews();
                // bt_topping.setEnabled(true);
                max_progress = 0;
                progressBar.setProgress(max_progress);
                cb_delivery.setChecked(false);
            }
        });


        //Using list iterator

//        Iterator litr= current_toppings.listIterator();
//
//        while(litr.hasNext()){
//
//            Log.d("check", "onCreate: " + litr.next());
//        }


        bt_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, OrderActivity.class);

                boolean isChecked = cb_delivery.isChecked();


                if(current_toppings.size()<1) {
                    Log.d("size", "onClick: " + current_toppings.size());

                    Toast.makeText(MainActivity.this, "Please add atleast one topping!", Toast.LENGTH_SHORT).show();
                }

                else {
                    Log.d("array", "onClick: " + current_toppings.toString());
                    intent.putStringArrayListExtra(Main_Key, current_toppings);
                    intent.putExtra(Sub_Key, isChecked);
                    startActivity(intent);
                    finish();
                }

            }
        });


    }

    @Override
    public void onClick(View v) {
        Log.d("demoTag", "onClick: " + v.getTag());
        current_toppings.remove(getName(v.getId()));
        fb.removeView((ImageView) v.getTag());
        int removeView = fb.getChildCount();
        progressBar.setProgress(removeView);
    }

    private String getName(int id) {
        switch (id) {
            case R.drawable.bacon:
                return "Bacon";
            case R.drawable.cheese:
                return "Cheese";


            case R.drawable.garlic:
                return "Garlic";


            case R.drawable.green_pepper:
                return "Green Pepper";


            case R.drawable.mashroom:
                return "Mushroom";


            case R.drawable.olive:
                return "Olives";


            case R.drawable.onion:
                return "Onions";


            case R.drawable.red_pepper:
                return "Red Pepper";


        }
        return "";
    }

    private int display(String temp) {


        switch (temp) {
            case "Bacon":
                return R.drawable.bacon;


            case "Cheese":
                return R.drawable.cheese;


            case "Garlic":
                return R.drawable.garlic;


            case "Green Pepper":
                return R.drawable.green_pepper;


            case "Mushroom":
                return R.drawable.mashroom;


            case "Olives":
                return R.drawable.olive;


            case "Onions":
                return R.drawable.onion;


            case "Red Pepper":
                return R.drawable.red_pepper;


        }
        return 0;
    }


}
