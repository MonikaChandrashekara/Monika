var express=require('express');
var app=express();
app.listen(8085);
app.set('view engine','ejs');
app.use('/css',express.static('./css'));
app.use('/image',express.static('./image'));
var catalogController = require('./controller/catalogController');
var profileController = require('./controller/profileController');

var session = require('express-session');
app.use(session({secret:'receipe'}));

app.use('/', catalogController);
app.use('/categories',catalogController);
app.use('/profileController',profileController);
app.use('/item',catalogController);
app.use('/profileController/myitem',profileController);
app.use('/categories/item/:itemCode',catalogController);
app.use('/contact', catalogController);
app.use('/about', catalogController);
app.use('/feedback/:itemCode', catalogController);
app.use('/profileController/save/:itemCode',profileController);
app.use('/profileController/delete/:itemCode',profileController);
app.use('/profileController/signOut', profileController);
app.use('/profileController/login',profileController);

module.exports = app;
