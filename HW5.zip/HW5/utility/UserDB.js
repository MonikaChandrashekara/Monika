class UserDB {

  /**
    * @param userdbModel
    */

  constructor() {

    var mongoose = require('mongoose');
    mongoose.connect('mongodb://localhost/nbadmonikaHW5', { useNewUrlParser: true });
    var userSchema = new mongoose.Schema({
      userID: Number,
      firstName:String,
      lastName:String,
      emailAddress:String,
      password:String,
      address:String,
      city:String,
      state:String,
      zipCode:Number,
      country:String,
      user_item: [{
        itemCode:Number,
        rating:Number,
        madeIt:String,
        catalogCategory:String,
        itemName:String
      }]
      });
      this.userdbModel = mongoose.model('User', userSchema, 'users');

    }

    getAllUsers(db){
      return new Promise((resolve, reject) => {
        db.find({}).then(data => {
          console.log("in find all " + data);
          resolve(data);
        }).catch(err => { return reject(err); })
      });
    }

    getUser(db, userID) {
    return new Promise((resolve, reject) => {
      db.find({
        $and: [{'userID':userID }]
      }).then(data => {
        resolve(data);
      }).catch(err => {
        return reject(err);
      })
    });
    }//end itemcode

    addUserItem(db, userId,firstName,lastName,email,pwd,address,city,state,zip,country,userItem) {

    return new Promise((resolve, reject) => {
      db.findOneAndUpdate({ $and: [{'userID': userId }] },
        // { $set: {'user_item.rating':userItem._itemCode},{'user_item.madeit':userItem._madeit} },
      { $set: {'userID':userId,'firstName':firstName,'lastName':lastName,
              'emailAddress':email,'password':pwd,'address':address,'city':city,
              'state':state,'zipCode':zip,'country':country,'user_item':userItem }
      },
      { new: true, upsert: true }, function (err, data) {
        //  console.log("data adduserItem", data);
          resolve(data);
        }).catch(erro => { return reject(err); });
    }
    )
  }//end addStudent


  getUserItems(db, userID) {
  return new Promise((resolve, reject) => {
    db.find({
      $and: [{'userID':userID }]
    }).lean().then(data => {
     console.log("get user items: ",data[0].user_item);
      resolve(data[0].user_item);
    }).catch(err => {
      return reject(err);
    })
  });
  }//end itemcode

  getDeleteItem(db, userId,firstName,lastName,email,pwd,address,city,state,zip,country,userItem) {
  return new Promise((resolve, reject) => {
    db.findOneAndUpdate({ $and: [{'userID': userId }] },
    { $set: {'userID':userId,'firstName':firstName,'lastName':lastName,
            'emailAddress':email,'password':pwd,'address':address,'city':city,
            'state':state,'zipCode':zip,'country':country,'user_item':userItem }
    },
    { new: true, upsert: true }, function (err, data) {
        resolve(data);
      }).catch(erro => { return reject(err); });
  }
  )
  }  // end DeleteItem


  addRating(db, userId,firstName,lastName,email,pwd,address,city,state,zip,country,userItem) {
    return new Promise((resolve, reject) => {
      db.findOneAndUpdate({ $and: [{'userID': userId }] },
      { $set: {'userID':userId,'firstName':firstName,'lastName':lastName,
              'emailAddress':email,'password':pwd,'address':address,'city':city,
              'state':state,'zipCode':zip,'country':country,'user_item':userItem }
      },
      { new: true, upsert: true }, function (err, data) {
          resolve(data);
        }).catch(erro => { return reject(err); });
    }
    )
}

deleteProfile(request){
  request.session.destroy();
}

getRegisteredUser(db,emailAddress ,password) {
return new Promise((resolve, reject) => {
  db.find({
    $and: [{'emailAddress':emailAddress , 'password':password }]
  }).then(data => {
    console.log("HEY IN GET REGISTRED USER METHOD :" ,data);
    resolve(data);
  }).catch(err => {
    return reject(err);
  })
});
}

}
module.exports = UserDB;
