class ItemDB {

/**
  * @param category
  * @param ItemModelDB
  */


  constructor() {
    var mongoose = require('mongoose');
    mongoose.connect('mongodb://localhost/nbadmonikaHW5', { useNewUrlParser: true });
    this.category = ["Appetizer", "Main Course"];
    var itemSchema = new mongoose.Schema({
     itemCode:Number,
     itemName:String,
     catalogCategory: String,
     description:String,
     rating:Number,
     imageURL:String,
     ingr: [] ,
     di: [],
     userID :Number
    });
    this.ItemModelDB = mongoose.model('Item', itemSchema, 'items'); //<- StudentInfo is the collection name in the database
  }

    getAllItems(db) {
      return new Promise((resolve, reject) => {
        db.find({}).then(data => {
          // console.log("ixn find all " + data);
          resolve(data);
        }).catch(err => { return reject(err); })
      });
    }

    getItem(db, itemCode) {
    return new Promise((resolve, reject) => {
      db.find({
        $and: [{'itemCode':itemCode }]
      }).then(data => {
        resolve(data);
      }).catch(err => {
        return reject(err);
      })
    });
    }//end itemcode

  checkItem (db, itemCode) {
      return new Promise((resolve, reject) => {
        db.find({
          $and: [{'itemCode':itemCode }]
        }).then(data => {
          resolve(data);
        }).catch(err => {
          return reject(err);
        })
      });
    }//end itemcode

    getCategories () {
      return this.category;
    }




}
module.exports = ItemDB;
