var express = require('express');
var routers = express.Router();
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var app = module.exports = express();
var userProfileInstance;
var userItemInstance;
var eachUser ;

const { body, validationResult} = require('express-validator/check');
app.use(bodyParser.text());




var ItemdbCatalogC= require('../controller/catalogController')
console.log("********** HI LOGGING IN PC **********", ItemdbCatalogC)
var itemPC= ItemdbCatalogC.ItemDBObject;
console.log("Hi i am logging DB MODEL itempc", itemPC);
var itemModelPC = itemPC.ItemModelDB;
console.log (" !!!! Logging itemDbModel :", itemModelPC);


var UserDB = require('../utility/UserDB');
var UserDBObject = new UserDB();
var userDbModel = UserDBObject.userdbModel;



routers.get('/myitem',urlencodedParser, async function(request, response, next) {


    if(request.session.theUser){
    let data = await  UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
    response.render('myitem',{data : data , profiledata: request.session.theUser, errors:''});
    }
    else {

      response.render('login',{ profiledata:"", errors:''});
    }
});


routers.post('/save/:itemCode', urlencodedParser, async function(request, response, next) {

    if(request.session.theUser){
    var flag =0;
    var itemCode = request.params.itemCode;
    var item = await itemPC.getItem(itemModelPC,itemCode );
    let items = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);


       if(itemCode>6 || itemCode<1){

         let  mydata = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
         console.log("ENTER THE IF CONDITION ");
         response.render('myitem',{data: mydata,profiledata:request.session.theUser});

       }

 else{
    for (var i = 0; i < items.length; i++){
      if(items[i].itemCode == itemCode){
        flag = flag +1 ;
        console.log("DUPLICATE ITEM FOUND #########################");
      }
    }

           if(flag==0){
            var Dict = {'itemCode':itemCode,'rating':"0",'madeIt':"off",
            'catalogCategory':item[0].catalogCategory,'itemName':item[0].itemName};
            if(items.length == []){
              items = [Dict];
            }else{
              items.push(Dict);
            }

            save = await UserDBObject.addUserItem(userDbModel,eachUser[0].userID,eachUser[0].firstName,
                              eachUser[0].lastName,eachUser[0].emailAddress,
                              eachUser[0].password,eachUser[0].address,eachUser[0].city,eachUser[0].state,
                              eachUser[0].zipCode,eachUser[0].country,items);

            }

            data = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
           console.log("data after save  part ",data);
    response.render('myitem',{data: data,profiledata:request.session.theUser});

}
}
else{
  var categories = await  itemPC.getCategories() ;
var  globalItem = await itemPC.getAllItems(itemModelPC);
  var data= {
      title:'Categories',
      path: request.url,
      categories: categories,
      items: globalItem
  }
    response.render('login', {data: data ,profiledata:"",errors:''});
}

});



routers.get('/save/:itemCode', body('itemCode').isNumeric() ,urlencodedParser, async function(request, response) {
if(request.session.theUser){

  var itemCode = request.params.itemCode;

  const errors = validationResult(request);
  if (!errors.isEmpty()) {
    sample = JSON.stringify(errors.mapped());
    sample = JSON.parse(sample)
   console.log("sample ", sample);
   let  mydata1 = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
    return  response.render('myitem',{ data: mydata1 ,profiledata:request.session.theUser, errors:sample});

  }

  if(itemCode>6 || itemCode<1){

    let  mydata = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
    console.log("ENTER THE IF CONDITION ");
    response.render('myitem',{data: mydata,profiledata:request.session.theUser});

  }
}

else {

  response.render('login',{ profiledata:"", errors:''});
}

});



routers.post('/rating',urlencodedParser, async function(request, response) {

         var itemCode =request.body.itemcode;
          var item =await itemPC.checkItem(itemModelPC,itemCode);
          let userItemsArray = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);

         for (var i = 0; i < userItemsArray.length; i++){
           if(userItemsArray[i].itemCode == itemCode){
             console.log("item code matched ",itemCode,"------", userItemsArray[i].itemCode );
             userItemsArray[i].madeIt = request.body.madeit;
             userItemsArray[i].rating = request.body.rating;

           }
         }
         console.log("userItemsArray @@@@@@@@@@@@@@@@@@@@@@@@@@:", userItemsArray);
         userProfileObject = await UserDBObject.addRating(userDbModel,eachUser[0].userID,eachUser[0].firstName,
                           eachUser[0].lastName,eachUser[0].emailAddress,
                           eachUser[0].password,eachUser[0].address,eachUser[0].city,eachUser[0].state,
                           eachUser[0].zipCode,eachUser[0].country,userItemsArray);
          console.log("userProfileObject @@@@@@@@@@@@@@@@@@@@@@@@@@:", userProfileObject);
         var  data = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
         console.log("HI FIND DATA when session new",data);
        response.render('myitem',{data : data, profiledata:request.session.theUser});

});


routers.post('/delete/:itemCode',urlencodedParser,async function(request, response, next) {

  var itemCode = request.params.itemCode;
  var userID= eachUser[0].userID;


   if(itemCode>6 || itemCode<1){

     var data = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
     response.render('myitem',{data : data , profiledata:request.session.theUser});

   }

    else{
     let UserItems = await UserDBObject.getUserItems(userDbModel,userID);
     var deleteIndex = 0
     let items = await UserDBObject.getUserItems(userDbModel,userID);
     for (var i = 0; i < items.length; i++){
       if(items[i].itemCode == itemCode){
         deleteIndex = i;
       }
     }
     items.splice(deleteIndex, 1);

    var userProfileObject = await UserDBObject.getDeleteItem(userDbModel,eachUser[0].userID,eachUser[0].firstName,
                  eachUser[0].lastName,eachUser[0].emailAddress,
                  eachUser[0].password,eachUser[0].address,eachUser[0].city,eachUser[0].state,
                  eachUser[0].zipCode,eachUser[0].country,items);

                  var data = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
                  response.render('myitem',{data : data , profiledata:request.session.theUser});

}

});


routers.get('/delete/:itemCode', body('itemCode').isNumeric(), urlencodedParser, async function(request, response) {
if(request.session.theUser){

   var itemCode = request.params.itemCode;

  const errors = validationResult(request);
  if (!errors.isEmpty()) {
    sample = JSON.stringify(errors.mapped());
    sample = JSON.parse(sample)
   console.log("sample ", sample);
   let  mydata2 = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
    return  response.render('myitem',{ data: mydata2 ,profiledata:request.session.theUser, errors:sample});

  }

  if(itemCode>6 || itemCode<1){

    var data = await UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
    response.render('myitem',{data : data , profiledata:request.session.theUser});

  }
}
else {

  response.render('login',{ profiledata:"", errors:''});
}

});


routers.get('/signOut',urlencodedParser, async function(request, response) {
    UserDBObject.deleteProfile(request);
    response.render('index',{ profiledata: ""});
});


routers.post('/login',urlencodedParser,  [body('emailAddress')
  .isEmail() ,
  body('password')
  .isAlpha()
  .isLength({ min: 3 })] , async function(request, response) {
  const errors = validationResult(request);
  if (!errors.isEmpty()) {
    sample = JSON.stringify(errors.mapped());
    sample = JSON.parse(sample)
   console.log("sample ", sample);
    return  response.render('login',{profiledata:"", errors:sample});

  }
 else{

var email = request.body.emailAddress;
var password = request.body.password;
eachUser = await UserDBObject.getRegisteredUser(userDbModel ,email ,password);

// please check here
if(eachUser[0] == undefined ){
  response.render('login',{profiledata:"" , errors:'invalid'});
}

else{
console.log("eachUser", eachUser[0]);
console.log("HEY CHECK THE EMAIL ID  IN POST METHOD !!!!!" ,email);
let data = await  UserDBObject.getUserItems(userDbModel,eachUser[0].userID);

request.session.theUser = eachUser ;

console.log("%%%%%%%%%%%%% logging session " ,request.session.theUser )
response.render('myitem',{data:data,profiledata:request.session.theUser});
}
}
});

routers.get('/login',urlencodedParser, async function(request, response) {
if(request.session.theUser){
let data = await  UserDBObject.getUserItems(userDbModel,eachUser[0].userID);
response.render('myitem',{data : data , profiledata: request.session.theUser, errors:''});
}
else {

  response.render('login',{ profiledata:"", errors:''});
}

});





module.exports = routers ;
