var express = require('express');
var router = express.Router();
var ItemDB = require('../utility/ItemDB');
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var mongoose = require('mongoose');


const { check , validationResult } = require('express-validator/check');


 var ItemDBObject = new ItemDB();
 var itemDbModel = ItemDBObject.ItemModelDB;
 var globalItem;





 console.log(" -------------------This a test to logg item model-----------", itemDbModel);


router.get('/',urlencodedParser,async function(req,res){
  if(req.session.theUser){
    console.log("get categories:",ItemDBObject.getCategories() );
    globalItem = await ItemDBObject.getAllItems(itemDbModel);
    console.log("get all items", globalItem);
  res.render('index', {profiledata:req.session.theUser});
  }
  else{
    console.log("get categories:",ItemDBObject.getCategories() );
        globalItem = await ItemDBObject.getAllItems(itemDbModel);
         console.log("get all items", globalItem);
    res.render('index', {profiledata:""});
  }

});

router.get('/categories.html',async  function(req, res) {

    var categories = await  ItemDBObject.getCategories() ;
    globalItem = await ItemDBObject.getAllItems(itemDbModel);
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: globalItem
    }

    if(req.session.theUser){
    res.render('categories', {data :data ,profiledata:req.session.theUser});

    }
    else{
      res.render('categories', {data: data ,profiledata:""});

    }
});

router.get('/about.html', async function(req,res){
  if(req.session.theUser){
  res.render('about', {profiledata:req.session.theUser});
  }
  else{
    res.render('about', {profiledata:""});
  }
});


router.get('/contact.html', async function(req,res){
  if(req.session.theUser){
  res.render('contact', {profiledata:req.session.theUser});
  }
  else{
    res.render('contact', {profiledata:""});
  }
});

router.get('/categories/item/:itemCode', check('itemCode').isNumeric() , async function(req, res, next) {

  var itemCode = req.params.itemCode;
  console.log("Item Code:"+itemCode);

   if(req.session.theUser){

  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    sample = JSON.stringify(errors.mapped());
    sample = JSON.parse(sample)
    console.log("sample ", sample);

    // var itemCode = req.params.itemCode;
    var categories = await ItemDBObject.getCategories() ;
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: globalItem
    }

    return  res.render('categories',{data: data, profiledata:req.session.theUser, errors:sample});

  }

    if(itemCode>6 || itemCode<1)
    {
      var categories = await ItemDBObject.getCategories() ;

      var data= {
          title:'Categories',
          path: req.url,
          categories: categories,
          items: globalItem
      }
      res.render('categories', { data: data, profiledata:req.session.theUser});
    }

    else{
    var item = await ItemDBObject.getItem( itemDbModel,itemCode);

    var data= {
        title:'Item',
        path: req.url,
        item: item[0]
    }
    res.render('item', { data: data,profiledata:req.session.theUser});

  }
}

else {

  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    sample = JSON.stringify(errors.mapped());
    sample = JSON.parse(sample)
    console.log("sample ", sample);

    // var itemCode = req.params.itemCode;
    var categories = await ItemDBObject.getCategories() ;
    var data= {
        title:'Categories',
        path: req.url,
        categories: categories,
        items: globalItem
    }

    return  res.render('categories',{data: data, profiledata:"", errors:sample});

  }

    if(itemCode>6 || itemCode<1)
    {
      var categories = await ItemDBObject.getCategories() ;

      var data= {
          title:'Categories',
          path: req.url,
          categories: categories,
          items: globalItem
      }
      res.render('categories', { data: data, profiledata:""});
    }

    else{
    var item = await ItemDBObject.getItem( itemDbModel,itemCode);

    var data= {
        title:'Item',
        path: req.url,
        item: item[0]
    }
    res.render('item', { data: data,profiledata:""});

  }

}

});


router.get('/feedback/:itemCode',check('itemCode').isNumeric(), async function(req, res, next) {
    var itemCode = req.params.itemCode;
    console.log("Item Code:"+itemCode);
    if(req.session.theUser){
      const errors = validationResult(req);

      if (!errors.isEmpty()) {
        sample = JSON.stringify(errors.mapped());
        sample = JSON.parse(sample)
       console.log("sample ", sample);

       var categories =  await ItemDBObject.getCategories() ;

       var data= {
           title:'Categories',
           path: req.url,
           categories: categories,
           items: globalItem
       }

       return res.render('categories', { data:data, profiledata:req.session.theUser , errors:sample});

      }

    if(itemCode>6 || itemCode<1)
    {
      var categories =  await ItemDBObject.getCategories() ;

      var data= {
          title:'Categories',
          path: req.url,
          categories: categories,
          items: globalItem
      }

      res.render('categories', { data:data, profiledata:req.session.theUser});
    }

    else{
      var item = await ItemDBObject.getItem(itemDbModel,itemCode);

    var data= {
        title:'Item',
        path: req.url,
        item: item[0]
    }
    res.render('feedback', { data: data,profiledata:req.session.theUser});
  }
}

else {

  var categories = await  ItemDBObject.getCategories() ;
  globalItem = await ItemDBObject.getAllItems(itemDbModel);
  var data= {
      title:'Categories',
      path: req.url,
      categories: categories,
      items: globalItem
  }
  res.render('login', {data: data ,profiledata:"" , errors:''});
}
});


module.exports = router;
module.exports.ItemDBObject = ItemDBObject;
