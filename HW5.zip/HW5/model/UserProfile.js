var UserItem = require('./../model/UserItem');
var itemDb = require('../utility/ItemDB');

class UserProfile {
    /**
     * Constructor
     * @param userID
     * @param userItem
     * @param userItems
     * @param ratingArray



     */


    constructor(userID) {

        this._userID = userID;
        this._userItems = [] ;
        this._ratingArray =[];


    }

    /** Getters and Setters */

    get userID() {
        return this._userID;
    }

    set userID(value) {
        this._userID = value;
    }

    get userItem() {
        return this._userItem;
    }

    set userItem(value) {
        this._userItem = value;
    }

     addItem(item){
       console.log(item);
      var duplicate = false;
      for(let i=0; i<this._userItems.length; i++){
        if (item._item._itemCode == this._userItems[i]._item._itemCode) {
          duplicate = true;
          break;
        }
      }
      if(!duplicate){
        this._userItems.push(item);
      }
    }



     getItems(){
      return this._userItems;
    }


    deleteItem(itemCode){
       let deleteIndex;
       for (var i = 0; i < this._userItems.length; i++) {
         if (this._userItems[i]._item._itemCode == itemCode ) {
           deleteIndex = i;
         }
       }
        this._userItems.splice(deleteIndex, 1);
        }

    feedbackRating(newRating,item,itemcode,madeit){
          var nr= newRating;
         this._ratingArray.push(nr);
         console .log (" new rating in feedbackRating is ", newRating)
         console.log("hi i am in feedbackRating function")
          var duplicateitem=false;
          var imp=itemDb.getItem(itemcode);
        console.log("old"  +imp._rating);
        imp._rating=newRating;
        console.log("new" +imp._rating);
         imp._madeIt=madeit;

        
          console.log("logging userItems" +this._userItems);

          for(let i=0; i<this._userItems.length; i++){
      if(this._userItems[i]._item._itemCode==itemcode)
      {
        console.log("hi i came in")
        this._userItems[i]._item._rating=imp._rating;
         console.log("updted rating is", this._userItems[i]._item._rating)
         duplicateitem=true;
         this._userItems[i]._item._madeIt=imp._madeIt;
      }
    }
  }

  deleteProfile(request){
    request.session.destroy();
 }
}

module.exports = UserProfile;
