package com.example.group1_9_homework5;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class NewsActivity extends AppCompatActivity {

    ListView listView;
   // ArrayAdapter<String> adapter;
   // ProgressBar progressBar;
    ArrayList<News> newsObjects;
    Source source;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
      //  progressBar = findViewById(R.id.progressBar);
        listView = (ListView)findViewById(R.id.listView);


        if(getIntent()!=null && getIntent().getExtras()!=null){

            source = (Source) getIntent().getExtras().getSerializable(MainActivity.Main_Key);

            Log.d("demo", "onCreate: " + source.name);
            Log.d("demo", "onCreate: "+ source.id);

            setTitle(""+source.name);

            if(isConnected()==true){
                Toast.makeText(NewsActivity.this, "Connected", Toast.LENGTH_SHORT).show();
                new NewsActivity.asyncParse1().execute("https://newsapi.org/v2/top-headlines?sources="+source.id+"&apiKey=63985033fbce40bfa0d78efb38827b48");

            }
            else
            {
                Toast.makeText(NewsActivity.this, "Not connected", Toast.LENGTH_SHORT).show();
            }

        }

    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(getBaseContext().CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != connectivityManager.TYPE_WIFI &&
                networkInfo.getType() != connectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }


    private class asyncParse1 extends AsyncTask<String, Void , ArrayList<News>> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
           // progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(final ArrayList<News> news) {
            super.onPostExecute(news);
           // progressBar.setVisibility(View.INVISIBLE);


            NewsAdapter adapter = new NewsAdapter(NewsActivity.this, R.layout.news_item, news);
            listView.setAdapter(adapter);

        }

        @Override
        protected ArrayList<News> doInBackground(String... params) {


            HttpURLConnection connection = null;
            InputStream inputStream = null;
            newsObjects = new ArrayList<News>();

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    inputStream = connection.getInputStream();
                    String json = IOUtils.toString(inputStream,"UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONArray articles = root.getJSONArray("articles");
                    for(int i=0; i<articles.length();i++){
                        JSONObject jsonarticle = articles.getJSONObject(i);
                        News news = new News();
                        news.author=jsonarticle.getString("author");
                        news.title=jsonarticle.getString("title");
                        news.url=jsonarticle.getString("url");
                        news.urltoImage=jsonarticle.getString("urlToImage");
                        news.publishedAt = jsonarticle.getString("publishedAt");
                        newsObjects.add(news);

                    }

                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }

            }
            return newsObjects;



        }
    }
}
