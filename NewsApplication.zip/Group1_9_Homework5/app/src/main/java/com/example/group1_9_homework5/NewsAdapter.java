package com.example.group1_9_homework5;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.squareup.picasso.Picasso;

import java.util.List;

public class NewsAdapter  extends ArrayAdapter<News> {

    public static String News_Key="news";

    public NewsAdapter(@NonNull Context context, int resource, @NonNull List<News> objects) {
        super(context, resource, objects);
    }

    public View getView(int position, View convertView, final ViewGroup parent) {
        final News news = getItem(position);
        ViewHolder viewHolder;


        if(convertView == null){ //if no view to re-use then inflate a new one
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.news_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.tv_NewsTitle = (TextView) convertView.findViewById(R.id.tv_NewsTitle);
            viewHolder.tv_NewsAuthor = (TextView) convertView.findViewById(R.id.tv_NewsAuthor);
            viewHolder.tv_NewsDate = (TextView) convertView.findViewById(R.id.tv_NewsDate);
            viewHolder.imageView= (ImageView)  convertView.findViewById(R.id.imageView);
            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        //set the data from the news object

        if (news.title.equals("")) {
            viewHolder.tv_NewsTitle.setText("No Title Found");
        } else {
            viewHolder.tv_NewsTitle.setText(news.title);
        }
        if (news.author.equals("")) {
            viewHolder.tv_NewsAuthor.setText("No Author Found");
        } else {
            viewHolder.tv_NewsAuthor.setText(news.author);
        }
        if (news.publishedAt.equals("")) {
            viewHolder.tv_NewsDate.setText("No Date Found");
        } else {
            viewHolder.tv_NewsDate.setText(news.publishedAt);
        }
        Picasso.get().load(news.urltoImage).into(viewHolder.imageView);
        viewHolder.newnews = news;

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("demo",""+news.title);
                Intent intent = new Intent(parent.getContext(),webView.class);
                intent.putExtra(News_Key,news);
                parent.getContext().startActivity(intent);

            }
        });

        return convertView;
    }

    //View Holder to cache the views
    private static class ViewHolder{
        TextView tv_NewsTitle;
        TextView tv_NewsAuthor;
        TextView tv_NewsDate;
        ImageView imageView;
        News newnews;

    }



}
