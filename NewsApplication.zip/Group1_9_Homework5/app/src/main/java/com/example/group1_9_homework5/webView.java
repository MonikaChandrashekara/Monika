package com.example.group1_9_homework5;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class webView extends AppCompatActivity {

    News news;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        webView =(WebView) findViewById(R.id.webView);


        if(getIntent()!=null && getIntent().getExtras()!=null){

            news = (News) getIntent().getExtras().getSerializable(NewsAdapter.News_Key);

            setTitle(news.title);

            //WebView webView = new WebView(this);
            webView.loadUrl(news.url);

        }

    }




}
