package com.example.group1_9_homework5;

import java.io.Serializable;

public class News implements Serializable {

     String author,title,url,urltoImage,publishedAt;

    public News() {
    }


    @Override
    public String toString() {
        return "News{" +
                "author='" + author + '\'' +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", urltoImage='" + urltoImage + '\'' +
                ", publishedAt='" + publishedAt + '\'' +
                '}';
    }
}
