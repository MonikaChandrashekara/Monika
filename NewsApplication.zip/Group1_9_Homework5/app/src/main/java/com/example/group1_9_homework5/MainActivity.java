/*
File Name : Group1_9_Homework05
Group: Group1_9
Group Members:
Monika Chandrashekara
Rohan Sriram
 */

package com.example.group1_9_homework5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Source> sourcesList ;
    ArrayList<String> sourcesListName;
    ProgressBar progressBar;
    ListView listView;
    ArrayAdapter<String> adapter;
    public static String Main_Key="main";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // sourcesListName = new ArrayList<String>();
        //sourcesList = new ArrayList<>();
       progressBar = findViewById(R.id.progressBar);
        listView = (ListView)findViewById(R.id.listView);


        if(isConnected()==true){
            Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_SHORT).show();
            new asyncParse().execute("https://newsapi.org/v2/sources?apiKey=63985033fbce40bfa0d78efb38827b48");

        }
        else
        {
            Toast.makeText(MainActivity.this, "Not connected", Toast.LENGTH_SHORT).show();
        }


    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(getBaseContext().CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != connectivityManager.TYPE_WIFI &&
                networkInfo.getType() != connectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }


    private class asyncParse extends AsyncTask<String, Void , ArrayList<Source>>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            //progressBar.setMessage("Loading Sources");
        }

        @Override
        protected ArrayList<Source> doInBackground(String... params) {

            HttpURLConnection connection = null;
            InputStream inputStream = null;
           sourcesList = new ArrayList<>();
           sourcesListName = new ArrayList<String>();

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    inputStream = connection.getInputStream();
                    String json = IOUtils.toString(inputStream, "UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONArray sources1 = root.getJSONArray("sources");
                    for (int i = 0; i < sources1.length(); i++) {
                        JSONObject jsonsource = sources1.getJSONObject(i);
                        Source sources = new Source();
                        sources.id = jsonsource.getString("id");
                        sources.name = jsonsource.getString("name");
                        sourcesList.add(sources);

                       Log.i("demo", "source name" + sources.name);

                       // sourcesListName.add(sources.name);
                    }

                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }

            }
            return sourcesList;
//            return  sourcesListName;
        }

        @Override
        protected void onPostExecute(final ArrayList<Source> sn) {
            super.onPostExecute(sn);
            progressBar.setVisibility(View.INVISIBLE);

            for(int i=0;i<sn.size();i++){
                sourcesListName.add(sn.get(i).name);
            }

            final ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, android.R.id.text1, sourcesListName);

            listView.setAdapter(adapter);


            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                   Log.d("demo","hi" +adapter.getItem(i));
                    Intent intent = new Intent(MainActivity.this ,NewsActivity.class);


                  //intent.putExtra(Main_Key,adapter.getItem(i) );

                   intent.putExtra(Main_Key, (Serializable) sn.get(i));
                   startActivity(intent);
                }
            });



        }
    }
    }



