package com.example.group1_9_homework04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EditMovieActivity extends AppCompatActivity {

    Spinner staticSpinner;
    SeekBar seekBar;
    TextView tv_rValue;
    EditText et_movieName;
    EditText mt_description;
    EditText et_Year;
    EditText et_IMDB;
    String text;
    Button bt_add;
//   public static int ratingValue;
  public  static  int releaseYear;
//    int value ;

    Button bt_save;

    public  static final String edit_key ="edit";
    Movie movie;
    String ratingCheck;

    private boolean mnflag, mdflag, myflag,miflag,mrflag =false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movie);

        setTitle("EDIT MOVIES");


        et_movieName = findViewById(R.id.et_movieName);
        mt_description = findViewById(R.id.mt_description);
        et_Year = findViewById(R.id.et_Year);
        et_IMDB = findViewById(R.id.et_IMDB);
        bt_add = findViewById(R.id.bt_save);
        staticSpinner = (Spinner) findViewById(R.id.spinner_genre);

        tv_rValue = findViewById(R.id.tv_rValue);
        bt_save=findViewById(R.id.bt_save);



        if(getIntent()!=null && getIntent().getExtras()!=null){

              movie = (Movie) getIntent().getExtras().getSerializable(MainActivity.Main_Key);

            Log.d("demoMain", "onCreate: " +movie.movieName);
            ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                    .createFromResource(EditMovieActivity.this, R.array.genre_list,
                            android.R.layout.simple_spinner_item);

            staticSpinner.setAdapter(staticAdapter);

             String compareValue = movie.movieGenre;
            if (compareValue != null) {
                int spinnerPosition = staticAdapter.getPosition(compareValue);
                staticSpinner.setSelection(spinnerPosition);
            }

            seekBar = findViewById(R.id.seekBar);
            seekBar.setMax(5);
            seekBar.setMin(0);
            Log.d("demo", "onCreate: check for rating  " +movie.movieRating);

              ratingCheck= movie.movieRating;
             if(ratingCheck.isEmpty()){
                 seekBar.setProgress(0);
                 tv_rValue.setText(""+0);

             }
             else
             {
                 seekBar.setProgress(Integer.valueOf(movie.movieRating));
                 tv_rValue.setText(""+movie.movieRating);
             }


            et_movieName.setText(movie.movieName);
            mt_description.setText(movie.movieDescription);
            et_IMDB.setText(movie.IMDBRating);
            et_Year.setText(movie.movieYear);


            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    tv_rValue.setText(""+i);

                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });

         bt_save.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {

                 text = staticSpinner.getSelectedItem().toString();





                 if(et_movieName.getText().toString().equals("")){
                     mnflag=true;
                     et_movieName.setError("Please enter a value");
                     Toast.makeText(EditMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                 }else
                 {
                     mnflag=false;
                 }
                 if(mt_description.getText().toString().equals("")){
                     mdflag=true;
                     mt_description.setError("Please enter a value");
                     Toast.makeText(EditMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                 }else
                 {
                     mdflag=false;
                 }
                 if(et_Year.getText().toString().equals("")){
                     myflag=true;
                     et_Year.setError("Please enter a value");
                     Toast.makeText(EditMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                 }else
                 {
                     myflag=false;
                     String y1 = et_Year.getText().toString();
                     releaseYear = Integer.parseInt(y1);
                 }
                 if(et_IMDB.getText().toString().equals("")){
                     miflag=true;
                     et_IMDB.setError("Please enter a value");
                     Toast.makeText(EditMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                 }else
                 {
                     miflag=false;
                 }
                 if(releaseYear<=1900 || releaseYear>2019){
                     myflag=true;
                     et_Year.setError("The year should be in the range 1900 to 2019");
                     Toast.makeText(EditMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                 }else
                 {
                     myflag=false;
                 }
                 if(tv_rValue.getText().toString().equals("")){
                     mrflag=true;
                     tv_rValue.setError("Please enter a  rating value");
                     Toast.makeText(EditMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                 }else
                 {
                     mrflag=false;
                 }


                 if(!mnflag && !myflag && !mdflag && !miflag && !mrflag) {
                     movie.setMovieName(et_movieName.getText().toString());
                     movie.setMovieDescription(mt_description.getText().toString());
                     movie.setMovieGenre(text);
                     movie.setMovieRating(tv_rValue.getText().toString());
                     movie.setMovieYear(et_Year.getText().toString());
                     movie.setIMDBRating(et_IMDB.getText().toString());


                     Intent intent = new Intent(EditMovieActivity.this, MainActivity.class);
                     intent.putExtra(edit_key, movie);
                     setResult(RESULT_OK, intent);
                     finish();

                 }

             }
         });


        }






    }
}
