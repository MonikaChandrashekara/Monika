package com.example.group1_9_homework04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ShowListByYear extends AppCompatActivity {

    TextView tv_MovieTitle;
    TextView tv_description;
    TextView tv_MovieGenre;
    TextView tv_rValue;
    TextView tv_YearValue;
    TextView tv_imdbLink;
    Button bt_finish;
    ImageButton ib_ShowFirst;
    ImageButton ib_ShowLast;
    ImageButton ib_Next;
    ImageButton ib_Previous;
    Movie movie;
    ArrayList<Movie>  movieListYear= new ArrayList<>();

    int index;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list_by_year);

        setTitle("MOVIES BY YEAR");


        tv_MovieTitle = findViewById(R.id.tv_MovieTitle);
        tv_description=findViewById(R.id.tv_description);
        tv_MovieGenre =findViewById(R.id.tv_MovieGenre);
        tv_rValue=findViewById(R.id.tv_rValue);
        tv_YearValue = findViewById(R.id.tv_YearValue);
        tv_imdbLink = findViewById(R.id.tv_indbLink);
        bt_finish=findViewById(R.id.bt_finish);
        ib_ShowFirst = findViewById(R.id.ib_ShowFirst);
        ib_ShowLast = findViewById(R.id.ib_ShowLast);
        ib_Next = findViewById(R.id.ib_Next);
        ib_Previous=findViewById(R.id.ib_Previous);

        if(getIntent()!=null && getIntent().getExtras()!=null)
        {

//            movie =  (Movie) getIntent().getExtras().getSerializable(MainActivity.Main_Key);

            movieListYear = (ArrayList<Movie>) getIntent().getExtras().getSerializable(MainActivity.Main_Key);

          //  movieListYear.add(movie);


            Collections.sort(movieListYear, new Comparator<Movie>() {

                @Override
                public int compare(Movie u1,Movie u2){
                    // TODO Auto-generated method stub

                    int  y1= Integer.valueOf(u1.movieYear);
                    int y2 = Integer.valueOf(u2.movieYear);
                     return y1-y2;
                }
            });

            Log.d("demo", "onCreate: check sorted year" +movieListYear.get(0).getMovieYear());



           tv_MovieTitle.setText(movieListYear.get(0).movieName);
           tv_description.setText(movieListYear.get(0).movieDescription);
           tv_MovieGenre.setText(movieListYear.get(0).movieGenre);
           tv_rValue.setText(movieListYear.get(0).movieRating +"/5");
           tv_YearValue.setText(movieListYear.get(0).movieYear);
           tv_imdbLink.setText(movieListYear.get(0).IMDBRating);



            ib_ShowFirst.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    index=0;
                    tv_MovieTitle.setText(movieListYear.get(0).movieName);
                    tv_description.setText(movieListYear.get(0).movieDescription);
                    tv_MovieGenre.setText(movieListYear.get(0).movieGenre);
                    tv_rValue.setText(movieListYear.get(0).movieRating +"/5");
                    tv_YearValue.setText(movieListYear.get(0).movieYear);
                    tv_imdbLink.setText(movieListYear.get(0).IMDBRating);


                }
            });


            ib_ShowLast.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    index=movieListYear.size()-1;
                    tv_MovieTitle.setText(movieListYear.get(movieListYear.size()-1).movieName);
                    tv_description.setText(movieListYear.get(movieListYear.size()-1).movieDescription);
                    tv_MovieGenre.setText(movieListYear.get(movieListYear.size()-1).movieGenre);
                    tv_rValue.setText(movieListYear.get(movieListYear.size()-1).movieRating +"/5");
                    tv_YearValue.setText(movieListYear.get(movieListYear.size()-1).movieYear);
                    tv_imdbLink.setText(movieListYear.get(movieListYear.size()-1).IMDBRating);
                }
            });


            ib_Next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    index++;
                    if(index< movieListYear.size()){

                        tv_MovieTitle.setText(movieListYear.get(index).movieName);
                        tv_description.setText(movieListYear.get(index).movieDescription);
                        tv_MovieGenre.setText(movieListYear.get(index).movieGenre);
                        tv_rValue.setText(movieListYear.get(index).movieRating +"/5");
                        tv_YearValue.setText(movieListYear.get(index).movieYear);
                        tv_imdbLink.setText(movieListYear.get(index).IMDBRating);


                    }
                }
            });

            ib_Previous.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    index--;

                    if(index >-1){

                        tv_MovieTitle.setText(movieListYear.get(index).movieName);
                        tv_description.setText(movieListYear.get(index).movieDescription);
                        tv_MovieGenre.setText(movieListYear.get(index).movieGenre);
                        tv_rValue.setText(movieListYear.get(index).movieRating +"/5");
                        tv_YearValue.setText(movieListYear.get(index).movieYear);
                        tv_imdbLink.setText(movieListYear.get(index).IMDBRating);


                    }

                }
            });

            bt_finish.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    setResult(RESULT_OK);
                    finish();

                }
            });



        }

    }


}
