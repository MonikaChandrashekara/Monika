package com.example.group1_9_homework04;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {


    Button bt_addMovie, bt_edit,bt_deleteMovie,bt_listYear,bt_listRating;
    ArrayList<Object>  movieList= new ArrayList<>();
    public static String Main_Key="main";
    public static String Main_EditKey="editmain";
    public static final int REQ_CODE = 101;
    public static final int REQ_EDITCODE = 102;
    public static final int REQ_YEARCODE = 103;
    public static final int REQ_RATINGCODE = 104;
    List<String> movieName = new ArrayList<>();
    int index;
    Movie movieMainObj;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       setTitle("My Favourite movies");

        bt_addMovie = findViewById(R.id.bt_addMovie);
        bt_edit=findViewById(R.id.bt_edit);
        bt_deleteMovie=findViewById(R.id.bt_deleteMovie);
        bt_listRating = findViewById(R.id.bt_listRating);
        bt_listYear = findViewById(R.id.bt_listYear);

        bt_addMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this ,AddMovieActivity.class);
                // intent.putExtra(Main_Key,movieList);

                startActivityForResult(intent, REQ_CODE);
                Toast.makeText(MainActivity.this, "passing intent", Toast.LENGTH_SHORT).show();


            }
        });

        bt_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              //  movieName.add(movieMainObj.movieName);

              final CharSequence[] movieAlert = movieName.toArray(new CharSequence[movieName.size()]);

                Log.d("demoMain", "onClick: " +movieAlert);

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose a Movie");

                builder.setItems(movieAlert, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        index= which;
                        Log.d("demoMain", "onClick: check index value after assigning" +index);
                        Intent intent = new Intent(MainActivity.this,EditMovieActivity.class);
                        intent.putExtra(Main_Key, (Serializable) movieList.get(which));
                        startActivityForResult(intent,REQ_EDITCODE);


                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });


        bt_deleteMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final CharSequence[] movieAlert = movieName.toArray(new CharSequence[movieName.size()]);

                Log.d("demoMain", "onClick: " +movieAlert);

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Choose a Movie to Delete");

                builder.setItems(movieAlert, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        movieList.remove(which);
                        movieName.remove(which);
                        Toast.makeText(MainActivity.this, "Selected movie is deleted", Toast.LENGTH_SHORT).show();


                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });


        bt_listYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              // Intent intent = new Intent(MainActivity.this,ShowListByYear.class);

             //   Intent intent = new Intent("android.intent.action.VIEW");

                if(movieList.size()>=1){
                    Intent intent = new Intent("android.intent.action.YEAR");
                    intent.putExtra(Main_Key,movieList);
                    startActivityForResult(intent,REQ_YEARCODE);

                }
                else
                {
                    Toast.makeText(MainActivity.this, "There are no movies to display", Toast.LENGTH_SHORT).show();
                }




            }
        });


        bt_listRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               // Intent intent = new Intent(MainActivity.this,ShowListByRatings.class);

                if(movieList.size()>=1){
                    Intent intent = new Intent("android.intent.action.RATE");
                    intent.putExtra(Main_Key,movieList);
                    startActivityForResult(intent,REQ_RATINGCODE);
                  //  startActivity(intent);

                }
                else{
                    Toast.makeText(MainActivity.this, "There are no movies to display", Toast.LENGTH_SHORT).show();
                }



            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQ_CODE){
            if(resultCode==RESULT_OK){

                 movieMainObj = (Movie) data.getExtras().getSerializable(AddMovieActivity.add_key);
                 movieList.add(movieMainObj);
                 movieName.add(movieMainObj.movieName);

                Log.d("demoMain", "onActivityResult: in Main");
                Log.d("demoMain", "onActivityResult: "+movieMainObj.getMovieName());



            }
        }

        if(requestCode==REQ_EDITCODE){
            if(resultCode==RESULT_OK){


                  movieMainObj = (Movie) data.getExtras().getSerializable(EditMovieActivity.edit_key);
                   movieList.set(index,movieMainObj);
                 movieName.set(index,movieMainObj.movieName);
                Log.d("demoMain", "onActivityResult:  check updated "+movieMainObj.getMovieName());
                Log.d("demoMain", "onActivityResult: check index value " + index);
               Log.d("demoMain", "onActivityResult: printing movie List " +movieList.size());
               // Log.d("demoMain", "onActivityResult: printing movie List " +movieList.get(1));


            }
        }

        if(requestCode==REQ_YEARCODE){
            if(resultCode==RESULT_OK){


                Toast.makeText(this, "In MainActivity", Toast.LENGTH_SHORT).show();


            }
        }

        if(requestCode==REQ_RATINGCODE){
            if(resultCode==RESULT_OK){


                Toast.makeText(this, "In MainActivity", Toast.LENGTH_SHORT).show();


            }
        }

    }



}
