package com.example.group1_9_homework04;

import java.io.Serializable;
import java.util.Comparator;

public class Movie implements Serializable {

    String movieName;
    String movieDescription;
    String movieGenre;
    String movieRating;
    String movieYear;
    String IMDBRating;

    public Movie(String movieName, String movieDescription, String movieGenre, String movieRating, String movieYear, String IMDBRating) {
        this.movieName = movieName;
        this.movieDescription = movieDescription;
        this.movieGenre = movieGenre;
        this.movieRating = movieRating;
        this.movieYear = movieYear;
        this.IMDBRating = IMDBRating;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieDescription() {
        return movieDescription;
    }

    public void setMovieDescription(String movieDescription) {
        this.movieDescription = movieDescription;
    }

    public String getMovieGenre() {
        return movieGenre;
    }

    public void setMovieGenre(String movieGenre) {
        this.movieGenre = movieGenre;
    }

    public String getMovieRating() {
        return movieRating;
    }

    public void setMovieRating(String movieRating) {
        this.movieRating = movieRating;
    }

    public String getMovieYear() {
        return movieYear;
    }

    public void setMovieYear(String movieYear) {
        this.movieYear = movieYear;
    }

    public String getIMDBRating() {
        return IMDBRating;
    }

    public void setIMDBRating(String IMDBRating) {
        this.IMDBRating = IMDBRating;
    }



    /*Comparator for sorting the list by roll no*/
//    public static Comparator<Movie> StuRollno = new Comparator<Movie>() {
//
//        public int compare(Movie s1, Movie s2) {
//
//            int  y1= Integer.valueOf(s1.getMovieYear());
//            int y2 = Integer.valueOf(s2.getMovieYear());
//
//            /*For ascending order*/
//            return y1-y2;
//
//            /*For descending order*/
//            //rollno2-rollno1;
//        }};
//


}
