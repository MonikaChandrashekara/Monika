package com.example.group1_9_homework04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AddMovieActivity extends AppCompatActivity {

     Spinner staticSpinner;
     SeekBar seekBar;
     TextView tv_rValue;
     EditText et_movieName;
     EditText mt_description;
     EditText et_Year;
     EditText et_IMDB;
     String text;
     Button bt_add;
   public static int ratingValue;
    public  static  int releaseYear;
    int value ;
    private boolean mnflag, mdflag, myflag,miflag,mrflag =false;

     public  static final String add_key ="add";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);

        setTitle("ADD MOVIES");

          et_movieName = findViewById(R.id.et_movieName);
          mt_description = findViewById(R.id.mt_description);
          et_Year = findViewById(R.id.et_Year);
          et_IMDB = findViewById(R.id.et_IMDB);
          bt_add = findViewById(R.id.bt_save);
         staticSpinner = (Spinner) findViewById(R.id.spinner_genre);
        seekBar = findViewById(R.id.seekBar);
        tv_rValue = findViewById(R.id.tv_rValue);
        seekBar.setMax(5);
        seekBar.setMin(0);
       // seekBar.setProgress(0);

        ArrayAdapter<CharSequence> staticAdapter = ArrayAdapter
                .createFromResource(AddMovieActivity.this, R.array.genre_list,
                        android.R.layout.simple_spinner_item);

        staticSpinner.setAdapter(staticAdapter);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tv_rValue.setText(""+i);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        bt_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                text = staticSpinner.getSelectedItem().toString();

                Log.d("demo", "onCreate: spinner  genre value " +text);



                if(et_movieName.getText().toString().equals("")){
                    mnflag=true;
                    et_movieName.setError("Please enter a value");
                    Toast.makeText(AddMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                }else
                {
                    mnflag=false;
                }
                if(mt_description.getText().toString().equals("")){
                    mdflag=true;
                    mt_description.setError("Please enter a value");
                    Toast.makeText(AddMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                }else
                {
                    mdflag=false;
                }
                if(et_Year.getText().toString().equals("")){
                    myflag=true;
                    et_Year.setError("Please enter a value");
                    Toast.makeText(AddMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                }else
                {
                    myflag=false;
                    String y1 = et_Year.getText().toString();
                    releaseYear = Integer.parseInt(y1);
                }
                if(et_IMDB.getText().toString().equals("")){
                    miflag=true;
                    et_IMDB.setError("Please enter a value");
                    Toast.makeText(AddMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                }else
                {
                    miflag=false;
                }
                if(releaseYear<=1900 || releaseYear>2019){
                    myflag=true;
                    et_Year.setError("The year should be in the range 1900 to 2019");
                    Toast.makeText(AddMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                }else
                {
                    myflag=false;
                }
                if(tv_rValue.getText().toString().equals("")){
                    mrflag=true;
                    tv_rValue.setError("Please enter a  rating value");
                    Toast.makeText(AddMovieActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                }else
                {
                    mrflag=false;
                }



                 if(!mnflag && !myflag && !mdflag && !miflag && !mrflag) {

                     Movie movieObj = new Movie(et_movieName.getText().toString(), mt_description.getText().toString(),
                             text, tv_rValue.getText().toString(), et_Year.getText().toString(), et_IMDB.getText().toString());


                     Intent intent = new Intent(AddMovieActivity.this, MainActivity.class);
                     intent.putExtra(add_key, movieObj);
                     setResult(RESULT_OK, intent);
                     Toast.makeText(AddMovieActivity.this, "Passing intent", Toast.LENGTH_SHORT).show();
                     finish();
                 }

            }
        });

    }
}
