/*
File Name : InClass05_Group1_9
Group: Group1_9
Group Members:
Monika Chandrashekara
Rohan Sriram
 */


package com.example.inclass07_group1_9;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    EditText et_input;
    TextView tv_limitValue;
    SeekBar seekBar;
    ProgressBar progressBar;
    RadioGroup radioGroup;
    RadioButton rb_trackRating , rb_ArtistRating;
    int limitProgress ;
    ArrayList<Songs> songslist;
    Button bt_Search;
    int flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView)findViewById(R.id.listView);
        et_input = findViewById(R.id.et_input);
        tv_limitValue = findViewById(R.id.tv_limitValue);
        seekBar = findViewById(R.id.seekBar);
        progressBar = findViewById(R.id.progressBar);
        radioGroup = findViewById(R.id.radioGroup);
        rb_trackRating = findViewById(R.id.rb_trackRating);
        rb_ArtistRating = findViewById(R.id.rb_ArtistRating);
        bt_Search = findViewById(R.id.bt_Search);
       seekBar.setMax(25);
       seekBar.setMin(5);
       progressBar.setVisibility(View.INVISIBLE);


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

                tv_limitValue.setText(""+i);
                limitProgress = i;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch(radioGroup.getCheckedRadioButtonId()){
                    case R.id.rb_trackRating:
                        flag=1;
                        break;

                    case R.id.rb_ArtistRating:
                        flag=0;
                        break;
                    default:
                        break;

                }

            }
        });

        bt_Search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(isConnected()==true){
                    Toast.makeText(MainActivity.this, "Connected", Toast.LENGTH_SHORT).show();
                    if(flag==1){
                        Log.d("demo", "onClick: in flag 1" );
                        new asyncParse().execute("http://api.musixmatch.com/ws/1.1/track.search?q="+et_input.getText()+"&page_size="
                                +tv_limitValue.getText()+"&s_artist_rating=desc&apikey=9988dc7f532498556b5b7b8abfefb7b8");
                    }
                    else if(flag==0){
                        Log.d("demo", "onClick: in flag 2" );
                        new asyncParse().execute("http://api.musixmatch.com/ws/1.1/track.search?q="+et_input.getText()+"&page_size="
                                +tv_limitValue.getText()+"&s_track_rating=desc&apikey=9988dc7f532498556b5b7b8abfefb7b8");
                    }

                }
                else
                {
                    Toast.makeText(MainActivity.this, "Not connected", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private boolean isConnected(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(getBaseContext().CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != connectivityManager.TYPE_WIFI &&
                networkInfo.getType() != connectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }


    private class asyncParse extends AsyncTask<String, Void , ArrayList<Songs>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressBar.setVisibility(View.VISIBLE);
            //progressBar.setMessage("Loading Sources");
        }

        @Override
        protected ArrayList<Songs> doInBackground(String... params) {

            HttpURLConnection connection = null;
            InputStream inputStream = null;
            songslist = new ArrayList<>();

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    inputStream = connection.getInputStream();
                    String json = IOUtils.toString(inputStream, "UTF-8");

                    JSONObject root = new JSONObject(json);
                    JSONObject message = root.getJSONObject("message");
                    JSONObject body = message.getJSONObject("body");
                    JSONArray track_list = body.getJSONArray("track_list");
                    for (int i = 0; i < track_list.length(); i++) {
                        JSONObject jsonsource = track_list.getJSONObject(i);
                        JSONObject et = jsonsource.getJSONObject("track");
                        Songs songs = new Songs();
                        songs.track_name = et.getString("track_name");
                        songs.album_name = et.getString("album_name");
                        songs.artist_name = et.getString("artist_name");
                        songs.track_share_url = et.getString("track_share_url");
                        songs.updated_time =et.getString("updated_time");
                        Log.d("demo", "doInBackground: " +songs.track_name);
                        songslist.add(songs);


                    }

                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }

            }
            return songslist;
//            return  sourcesListName;
        }

        @Override
        protected void onPostExecute(final ArrayList<Songs> sn) {
            super.onPostExecute(sn);
            progressBar.setVisibility(View.INVISIBLE);

            Log.d("demo", "onPostExecute: " + sn.toString());

            SongsAdapter adapter = new SongsAdapter(MainActivity.this, R.layout.songs_item, sn);
            listView.setAdapter(adapter);



        }
    }

}
