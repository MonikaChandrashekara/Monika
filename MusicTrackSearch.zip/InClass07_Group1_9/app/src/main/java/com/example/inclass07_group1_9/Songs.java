package com.example.inclass07_group1_9;

public class Songs {


    String track_name,album_name, artist_name , updated_time, track_share_url;


    public Songs() {
    }


    @Override
    public String toString() {
        return "Songs{" +
                "track_name='" + track_name + '\'' +
                ", album_name='" + album_name + '\'' +
                ", artist_name='" + artist_name + '\'' +
                ", updated_time='" + updated_time + '\'' +
                ", track_share_url='" + track_share_url + '\'' +
                '}';
    }
}
