package com.example.inclass07_group1_9;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class SongsAdapter  extends ArrayAdapter<Songs> {
    public static String Song_Key="news";


    public SongsAdapter(@NonNull Context context, int resource, @NonNull List<Songs> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull final ViewGroup parent) {

        final Songs songs = getItem(position);
        ViewHolder viewHolder;
        Log.d("demo", "getView: " + songs.track_name);

        if(convertView == null){ //if no view to re-use then inflate a new one
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.songs_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.tv_Track = (TextView) convertView.findViewById(R.id.tv_Track);
            viewHolder.tv_Artist = (TextView) convertView.findViewById(R.id.tv_Artist);
            viewHolder.tv_Album = (TextView) convertView.findViewById(R.id.tv_Album);
            viewHolder.tv_Date= (TextView)  convertView.findViewById(R.id.tv_Date);
            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        //set the data from the news object

        if (songs.track_name.equals("")) {
            viewHolder.tv_Track.setText("No Title Found");
        } else {
            viewHolder.tv_Track.setText(songs.track_name);
        }
        if (songs.artist_name.equals("")) {
            viewHolder.tv_Artist.setText("No Artist Found");
        } else {
            viewHolder.tv_Artist.setText(songs.artist_name);
        }
        if (songs.album_name.equals("")) {
            viewHolder.tv_Album.setText("No Album Found");
        } else {
            viewHolder.tv_Album.setText(songs.album_name);
        }
        if (songs.updated_time.equals("")) {
            viewHolder.tv_Date.setText("No Album Found");
        } else {

            String date = songs.updated_time;
            date = date.substring(0,10);
           String[] str = date.split("-");
            Log.d("demo", "getView: " +date);
            viewHolder.tv_Date.setText(str[1]+"-"+str[2]+"-"+str[0]);
        }


        viewHolder.newsongs = songs;

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = songs.track_share_url;
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                parent.getContext().startActivity(intent);

            }
        });

        return convertView;


    }



    private static class ViewHolder{
        TextView tv_Track;
        TextView tv_Artist;
        TextView tv_Album;
        TextView tv_Date;
        Songs newsongs;

    }
}
