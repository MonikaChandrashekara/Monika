package com.example.group1_9_hw06;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link DisplayMyProfile.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class DisplayMyProfile extends Fragment {

    TextView name;
    TextView dept;
    TextView studentID;
    ImageView iv_avatar;
    Button bt_edit;


    private OnFragmentInteractionListener mListener;

    public DisplayMyProfile() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_display_my_profile, container, false);
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        name = getActivity().findViewById(R.id.tv_name);
        dept = getActivity().findViewById(R.id.tv_dept);
        studentID = getActivity().findViewById(R.id.tv_studentID);
        bt_edit = getActivity().findViewById(R.id.bt_edit);
        iv_avatar = getActivity().findViewById(R.id.iv_avatar);

        if(MainActivity.sharedpref.contains("myprofile")){

            getActivity().setTitle("Display My Profile");
            String prof = MainActivity.sharedpref.getString("myprofile","");
            Gson gson = new Gson();
            Profile profilenew= gson.fromJson(prof, Profile.class);

            name.setText(profilenew.getFirstname()+" " +profilenew.getLastname());
            studentID.setText(profilenew.getStudentID());
            dept.setText(profilenew.getDept());

            String image = profilenew.getProfileImage();
            switch (image){

                case "avatar_f1":
                    iv_avatar.setImageResource(R.drawable.avatar_f_1);
                    break;

                case "avatar_f2":
                    iv_avatar.setImageResource(R.drawable.avatar_f_2);
                    break;

                case "avatar_f3":
                    iv_avatar.setImageResource(R.drawable.avatar_f_3);
                    break;

                case "avatar_m1":
                    iv_avatar.setImageResource(R.drawable.avatar_m_1);
                    break;

                case "avatar_m2":
                    iv_avatar.setImageResource(R.drawable.avatar_m_2);
                    break;

                case "avatar_m3":
                    iv_avatar.setImageResource(R.drawable.avatar_m_3);
                    break;

                default:
                    iv_avatar.setImageResource(R.drawable.select_image);
                    break;


            }

        }

        bt_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mListener.onEditFragment();
            }
        });



    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name

      public  void onEditFragment();

    }
}
