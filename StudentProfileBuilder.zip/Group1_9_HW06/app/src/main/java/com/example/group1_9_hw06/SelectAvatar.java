package com.example.group1_9_hw06;

import android.content.Context;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SelectAvatar.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class SelectAvatar extends Fragment {

    public  static String avatar="";

    private OnFragmentInteractionListener mListener;
    private ImageView iv_avatar_f1;
    private ImageView iv_avatar_f2;
    private ImageView iv_avatar_f3;
    private ImageView iv_avatar_m1;
    private ImageView iv_avatar_m2;
    private ImageView iv_avatar_m3;

    public SelectAvatar() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_select_avatar, container, false);

        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        getActivity().setTitle("Select Avatar");
        iv_avatar_m1= getActivity().findViewById(R.id.iv_avatar_m1);
        iv_avatar_m2= getActivity().findViewById(R.id.iv_avatar_m2);
        iv_avatar_m3= getActivity().findViewById(R.id.iv_avatar_m3);
        iv_avatar_f1= getActivity().findViewById(R.id.iv_avatar_f1);
        iv_avatar_f2= getActivity().findViewById(R.id.iv_avatar_f2);
        iv_avatar_f3= getActivity().findViewById(R.id.iv_avatar_f3);


        iv_avatar_f1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 avatar = "avatar_f1";
                mListener.AvatarImageSelected(avatar);
            }
        });

        iv_avatar_f2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 avatar="avatar_f2";
                mListener.AvatarImageSelected(avatar);
            }
        });

        iv_avatar_f3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 avatar="avatar_f3";
                mListener.AvatarImageSelected(avatar);
            }
        });

        iv_avatar_m1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                avatar="avatar_m1";
                mListener.AvatarImageSelected(avatar);
            }
        });

        iv_avatar_m2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                avatar="avatar_m2";
                mListener.AvatarImageSelected(avatar);
            }
        });

        iv_avatar_m3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 avatar="avatar_m3";
                mListener.AvatarImageSelected(avatar);
            }
        });



    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {

        public void AvatarImageSelected(String str);

    }
}
