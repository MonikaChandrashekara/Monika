package com.example.group1_9_hw06;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.gson.Gson;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link MyProfile.OnFragmentInteractionListener} interface
 * to handle interaction events.
 */
public class MyProfile extends Fragment {

    private OnFragmentInteractionListener mListener;
    private EditText et_firstname;
    private EditText et_lastname;
    private EditText et_studentid;
    private ImageView iv_selectimage;
    private RadioGroup radiogroupDept;
    private RadioButton rb_CS;
    private RadioButton rb_BIO;
    private RadioButton rb_SIS;
    private RadioButton rb_other;
    private Button bt_save;

    Profile profile = new Profile();

    public boolean fnflag, lnflag, deptflag, studentidflag= false;

    public MyProfile() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_my_profile, container, false);


        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        iv_selectimage = getActivity().findViewById(R.id.iv_selectimage);
        et_firstname = getActivity().findViewById(R.id.et_firstname);
        et_lastname= getActivity().findViewById(R.id.et_lastname);
        et_studentid = getActivity().findViewById(R.id.et_studentid);
        radiogroupDept = getActivity().findViewById(R.id.radiogroupDept);
        rb_CS = getActivity().findViewById(R.id.rb_CS);
        rb_BIO = getActivity().findViewById(R.id.rb_BIO);
        rb_SIS = getActivity().findViewById(R.id.rb_SIS);
        rb_other=getActivity().findViewById(R.id.rb_other);
        bt_save = getActivity().findViewById(R.id.bt_save);
        rb_CS.setChecked(true);
        profile.setDept("CS");


        radiogroupDept.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                if (i == R.id.rb_CS) {
                    profile.setDept("CS");
                } else if (i == R.id.rb_SIS) {
                    profile.setDept("SIS");
                } else if (i==R.id.rb_BIO) {
                    profile.setDept("BIO");
                }else if(i==R.id.rb_other){
                    profile.setDept("other");
                }
            }
        });


        if(MainActivity.sharedpref.contains("myprofile")){

            getActivity().setTitle("My Profile");
            String prof = MainActivity.sharedpref.getString("myprofile","");
            Gson gson= new Gson();
            Profile profilenew = gson.fromJson(prof,Profile.class);
            et_firstname.setText(profilenew.getFirstname());
            et_lastname.setText(profilenew.getLastname());
            et_studentid.setText(profilenew.getStudentID());

            switch(profilenew.getDept()){
                case "CS":
                    rb_CS.setChecked(true);
                    profile.setDept("CS");
                    break;

                case "SIS":
                    rb_SIS.setChecked(true);
                    profile.setDept("SIS");
                    break;

                case "BIO":
                    rb_BIO.setChecked(true);
                    profile.setDept("BIO");
                    break;

                case "other":
                    rb_other.setChecked(true);
                    profile.setDept("other");
                    break;

            }

            switch (profilenew.getProfileImage()){

                case "avatar_f1":
                    iv_selectimage.setImageResource(R.drawable.avatar_f_1);
                    profile.setProfileImage("avatar_f1");
                    break;

                case "avatar_f2":
                    iv_selectimage.setImageResource(R.drawable.avatar_f_2);
                    profile.setProfileImage("avatar_f2");
                    break;

                case "avatar_f3":
                    iv_selectimage.setImageResource(R.drawable.avatar_f_3);
                    profile.setProfileImage("avatar_f3");
                    break;

                case "avatar_m1":
                    iv_selectimage.setImageResource(R.drawable.avatar_m_1);
                    profile.setProfileImage("avatar_m1");
                    break;

                case "avatar_m2":
                    iv_selectimage.setImageResource(R.drawable.avatar_m_2);
                    profile.setProfileImage("avatar_m2");
                    break;

                case "avatar_m3":
                    iv_selectimage.setImageResource(R.drawable.avatar_m_3);
                    profile.setProfileImage("avatar_m3");
                    break;

                default:
                    iv_selectimage.setImageResource(R.drawable.select_image);
                    profile.setProfileImage("select_image");
                    break;
            }

        }



      if(MainActivity.sharedpref.contains("profileimage")){

          String image = MainActivity.sharedpref.getString("profileimage","");

          switch (image){

              case "avatar_f1":
                  iv_selectimage.setImageResource(R.drawable.avatar_f_1);
                  profile.setProfileImage("avatar_f1");
                  break;

              case "avatar_f2":
                  iv_selectimage.setImageResource(R.drawable.avatar_f_2);
                  profile.setProfileImage("avatar_f2");
                  break;

              case "avatar_f3":
                  iv_selectimage.setImageResource(R.drawable.avatar_f_3);
                  profile.setProfileImage("avatar_f3");
                  break;

              case "avatar_m1":
                  iv_selectimage.setImageResource(R.drawable.avatar_m_1);
                  profile.setProfileImage("avatar_m1");
                  break;

              case "avatar_m2":
                  iv_selectimage.setImageResource(R.drawable.avatar_m_2);
                  profile.setProfileImage("avatar_m2");
                  break;

              case "avatar_m3":
                  iv_selectimage.setImageResource(R.drawable.avatar_m_3);
                  profile.setProfileImage("avatar_m3");
                  break;

              default:
                  iv_selectimage.setImageResource(R.drawable.select_image);
                  profile.setProfileImage("select_image");
                  Toast.makeText(getActivity(), "Please select an avatar", Toast.LENGTH_SHORT).show();
                  break;
          }

      }

        getActivity().findViewById(R.id.iv_selectimage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.gotoAvatarFragment();
            }
        });



        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(et_firstname.getText().toString().equals("")){
                    fnflag =true;
                    Toast.makeText(getActivity(), "Please enter the details for all the fields", Toast.LENGTH_SHORT).show();
                    et_firstname.setError("Please enter first name");
                }
                else{
                    fnflag =false;
                    et_firstname.setError(null);
                }
                if(et_lastname.getText().toString().equals(""))
                {
                    lnflag=true;
                    Toast.makeText(getActivity(), "Please enter the details for all the fields", Toast.LENGTH_SHORT).show();
                    et_lastname.setError("Please enter last name");
                }
                else{
                    lnflag= false;
                    et_lastname.setError(null);
                }
                if(et_studentid.getText().toString().equals("") || (et_studentid.getText().toString().length()!=9)){
                    studentidflag=true;
                    Toast.makeText(getActivity(), "Please enter the details for all the fields", Toast.LENGTH_SHORT).show();
                    et_studentid.setError("Please enter studentID with 9 positive digits");
                }
                else{
                    studentidflag=false;
                    et_studentid.setError(null);
                }


                 if(iv_selectimage.getDrawable().getConstantState()== getResources().getDrawable(R.drawable.select_image).getConstantState()){
                     profile.setProfileImage("select_image");
                 }


                if(!fnflag && !lnflag && !studentidflag && !deptflag) {
                    profile.setFirstname(et_firstname.getText().toString());
                    profile.setLastname(et_lastname.getText().toString());
                    profile.setStudentID(et_studentid.getText().toString());
                    mListener.addProfile(profile);
                }

            }
        });

    }




    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name

        public void gotoAvatarFragment();

        public void addProfile(Profile profile);

    }
}
