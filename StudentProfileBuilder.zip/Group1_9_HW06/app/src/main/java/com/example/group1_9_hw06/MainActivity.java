/*
Group1_9 : Homework 06
Monika Chandrashekara
Rohan Sriram
*/
package com.example.group1_9_hw06;

import androidx.appcompat.app.AppCompatActivity;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;

public class MainActivity extends AppCompatActivity implements MyProfile.OnFragmentInteractionListener, SelectAvatar.OnFragmentInteractionListener,DisplayMyProfile.OnFragmentInteractionListener {

    private MyProfile myProfile;
    private DisplayMyProfile displayMyProfile;
    private SelectAvatar selectAvatar;
    public static SharedPreferences sharedpref ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myProfile = new MyProfile();
        displayMyProfile = new DisplayMyProfile();
        selectAvatar = new SelectAvatar();
        sharedpref = getPreferences(MODE_PRIVATE);


        if(sharedpref.contains("myprofile")){
            setTitle("Display My Profile");
            getSupportFragmentManager().beginTransaction().add(R.id.main_container,displayMyProfile,"displaymyProfile_fragment").commit();
        }else{
            setTitle("My Profile");
            getSupportFragmentManager().beginTransaction().add(R.id.main_container,myProfile,"myProfile_fragment")
                    .commit();
        }

    }

    @Override
    public void gotoAvatarFragment() {


//        getSupportFragmentManager().beginTransaction().replace(R.id.main_container, new SelectAvatar(),"selectAvatar_fragment")
//                .addToBackStack(null).commit();

         getSupportFragmentManager().beginTransaction()
                 .replace(R.id.main_container,selectAvatar,"selectavatar").commit();

    }

    @Override
    public void addProfile(Profile profile) {

        SharedPreferences.Editor prefsEditor = sharedpref.edit();
        Gson gson = new Gson();
        String json = gson.toJson(profile);
        prefsEditor.putString("myprofile",json);
        prefsEditor.commit();


        getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_container,displayMyProfile)
                .commit();

    }

    @Override
    public void onBackPressed() {

        if(getSupportFragmentManager().getBackStackEntryCount() >0){

            getSupportFragmentManager().popBackStack();
        }else
        {
            super.onBackPressed();
        }

    }


    @Override
    public void AvatarImageSelected(String str) {

//        Log.d("demo", "AvatarImageSelected: IN MAIN" +str);
//        getSupportFragmentManager().popBackStack();

        sharedpref.edit().putString("profileimage",str).commit();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_container, myProfile)
                .commit();


    }

    @Override
    public void onEditFragment() {

        getSupportFragmentManager().beginTransaction().replace(R.id.main_container,myProfile)
                .commit();

    }
}
