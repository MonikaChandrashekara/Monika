package com.example.inclass05_group1_9;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView tv_keyword;
    ImageView iv_photo;
    Button bt_go;
    ImageButton ib_prev;
    ImageButton ib_next;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bt_go = findViewById(R.id.bt_go);
        ib_next =findViewById(R.id.ib_next);
        ib_prev = findViewById(R.id.ib_prev);
        progressBar = findViewById(R.id.progressBar);

        bt_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isConnected()==true) {
                    Toast.makeText(MainActivity.this, "CONNECTED", Toast.LENGTH_SHORT).show();
                    new getImageAsync().execute("http://dev.theappsdr.com/apis/photos/keywords.php");
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Not connected", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }


    private boolean isConnected () {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(getBaseContext().CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null || !networkInfo.isConnected() || (networkInfo.getType() != connectivityManager.TYPE_WIFI &&
                networkInfo.getType() != connectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class getImageAsync extends AsyncTask<String, Void, String> {

        String key ="";

        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);

        }

        @Override
        protected String doInBackground(String... params) {


            StringBuilder stringBuilder = new StringBuilder();
            HttpURLConnection connection = null;
            InputStream inputStream = null;
            BufferedReader reader = null;
            String result = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    inputStream = connection.getInputStream();
//
                    result = IOUtils.toString(inputStream,"UTF-8");
                    Log.d("demo", "doInBackground: " +result);

                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            return result;
        }

        @Override
        protected void onPostExecute(String s) {

            Log.d("demo", "onPostExecute: HEY CHECK");
            if (s != null) {
                Log.d("demo", s);
            } else {
                Log.d("demo", "onPostExecute: NO RESULT");
            }


            String str = s;
            final String[] arrOfStr = str.split(";");


            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Choose a Keyword");

            builder.setItems(arrOfStr, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                   key= arrOfStr[which];
                    Log.d("demo", "onClick:  plzz" +key);
                    tv_keyword=findViewById(R.id.tv_keyword);
                    tv_keyword.setText(key.toString());
                   new  getImageListAsync(key).execute(" http://dev.theappsdr.com/apis/photos/index.php?keyword="+arrOfStr[which]);
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();



        }
    }

    private class getImageListAsync extends AsyncTask<String, Void, String> {

        String key;
        ArrayList<String> image = new ArrayList<>();
        int index =0;





        public getImageListAsync(String key) {
            this.key = key;
        }

        @Override
        protected String doInBackground(String... params) {

            StringBuilder stringBuilder = new StringBuilder();
            HttpURLConnection connection = null;
            InputStream inputStream = null;
            BufferedReader reader = null;
            String result = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK){
                    inputStream = connection.getInputStream();
//
                    result = IOUtils.toString(inputStream,"UTF-8");
                    Log.d("demo", "doInSecondBackground: " +result);

                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            return result;

        }



        @Override
        protected void onPostExecute(String s) {

            String sampleString = s;
            String[] items = sampleString.split("\n");

            final List<String> itemList = Arrays.asList(items);
            final int size = itemList.size();
            iv_photo= findViewById(R.id.iv_photo);
            new getthirdAsync(iv_photo).execute(itemList.get(0));
            progressBar.setVisibility(View.INVISIBLE);

            ib_next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    index++;
                    if(index <= size){
                        if(index == size){
                            index = 0;
                        }
                        progressBar.setVisibility(View.VISIBLE);
                        new getthirdAsync(iv_photo).execute(itemList.get(index));
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                }
            });


            ib_prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    index--;
                    if(index==-1){
                        index = size -1;
                    }
                    progressBar.setVisibility(View.VISIBLE);
                    new getthirdAsync(iv_photo).execute(itemList.get(index));
                    progressBar.setVisibility(View.INVISIBLE);
                }
            });





        }

    }

    private class getthirdAsync extends AsyncTask<String, Void, Void> {

        ImageView iv_photo;
        Bitmap bitmap = null;

        public getthirdAsync(ImageView iv_photo) {
            this.iv_photo = iv_photo;
        }

        @Override
        protected Void doInBackground(String... params) {

            HttpURLConnection connection = null;
            try {
                URL  url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if(connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    bitmap= BitmapFactory.decodeStream(connection.getInputStream());
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }

            return null;


        }

        @Override
        protected void onPostExecute(Void aVoid) {

            if(bitmap!= null && iv_photo!=null){
                iv_photo.setImageBitmap(bitmap);
            }

        }
    }

    }



